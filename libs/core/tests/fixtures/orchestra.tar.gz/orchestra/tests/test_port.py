"""Isolated integration tests for the orchestrator/player scripts.

Real temporary git repositories; tmux, claude and codex are stateful mocks. The tmux mock
enforces tmux's ~16 KiB command limit, exact `=name`/`=name:` targeting, remain-on-exit
(a pane goes dead when its command exits) and new-session's refusal of a name that is already
in use. It models session user options ("tags": set-option, set-option -u, show-options -qv
and `#{@tag}` expansion in -F formats), session_created/session_path in list-sessions and
list-panes formats, and named paste buffers (load-buffer from stdin, show-buffer,
delete-buffer, paste-buffer -d), which the scripts use instead of files for every piece of
session state. A session's name is a label; its identity is its tags, so several tests plant
foreign sessions that wear the label a player would get.
Run: python3 test_port.py  (SKILLS_ROOT selects the installation to test; default is this
plugin's skills/ directory). The expected Claude player invocation defaults to the Claude
plugin in both layouts, with an explicit ORCHESTRA_CLAUDE_SKILL override for standalone
Claude installations.
"""
import os, hashlib, json, re, subprocess, tempfile, unittest
from pathlib import Path
ROOT = Path(os.environ.get('SKILLS_ROOT', Path(__file__).resolve().parent.parent/'skills'))
def player_invocation():
    m = ROOT.parent/'.claude-plugin/plugin.json'
    if m.exists():
        found = re.search(r'"name"\s*:\s*"([^"]+)"', m.read_text())
        if found: return '/%s:player' % found.group(1)
    return '/orchestra:player'
INV = player_invocation()
ID = '11111111-2222-3333-4444-555555555555'
UUID = '0199a000-1111-7000-8000-000000000042'
PEER = '1234567890abcdef1234567890abcdef'
RESTART = 'Your session was restarted in this worktree'
STAMP = r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ'
# Every @session-* key the scripts name: the convention's core keys Orchestra writes (the status
# keys only to withdraw them), its own extensions, and n10's branch extension, which it reads.
TAGS = ['@session-version', '@session-agent', '@session-launcher', '@session-pane', '@session-cwd', '@session-worktree', '@session-repo',
        '@session-status', '@session-status-kind', '@session-status-at',
        '@session-x-orchestra-session-type', '@session-x-orchestra-branch', '@session-x-orchestra-orchestrator',
        '@session-x-orchestra-orchestrator-config', '@session-x-orchestra-launching', '@session-x-orchestra-last-report',
        '@session-x-orchestra-claude-session', '@session-x-orchestra-target', '@session-x-orchestra-agent-provisional', '@session-x-n10-branch']
# Pinned with Kirby (CLAUDE.md carries the same table): sanitize() and the session labels built
# from it must agree byte for byte in both implementations.
SANITIZE = [('feature/x', 'feature-x'), ('release/v1.0:rc1', 'release-v1-0-rc1'), ('a/b_c-d', 'a-b_c-d'), ('plain', 'plain')]
LABELS = [  # (repo path, session type, branch, label)
    ('/home/u/Kirby', 'worktree', 'feature/x', 'Kirby-feature-x'),
    ('/srv/agent-plugins', 'worktree', 'fix/typo.v1.2:rc', 'agent-plugins-fix-typo-v1-2-rc'),
    ('/x/my.repo', 'worktree', 'main', 'my-repo-main'),
    ('/home/u/Kirby', 'shell', '', 'Kirby-shell'),
    ('/home/u/Kirby', 'agent', '', 'Kirby-agent'),
    # Overflow: 200 characters exactly, 195 of the sanitized label, "-" and the first 4 hex
    # characters of sha256 over the UNSANITIZED "<basename>-<branch>" string.
    ('/x/r', 'worktree', 'a'*250, 'r-' + 'a'*193 + '-0a22'),
    ('/x/agent-plugins', 'worktree', 'a'*250, 'agent-plugins-' + 'a'*181 + '-1fad'),
    # Same sanitized head, different unsanitized input: the tails differ only if the hash is over
    # the unsanitized string (hashing the sanitized one gives ec93 for both).
    ('/x/r', 'worktree', 'a/'*125, 'r-' + 'a-'*96 + 'a-6e0f'),
    ('/x/r', 'worktree', 'a.'*125, 'r-' + 'a-'*96 + 'a-b373'),
    # Terminal tabs hash "<basename>-shell" / "<basename>-agent" (the bare basename would give ae7b for both).
    ('/x/' + 'b'*220, 'shell', '', 'b'*195 + '-930d'),
    ('/x/' + 'b'*220, 'agent', '', 'b'*195 + '-9fb6'),
]
TMUX_MOCK = r'''#!/usr/bin/env python3
import os, sys, json, re, hashlib, subprocess
from pathlib import Path
b = Path(os.environ['ORCH_TEST_TMP']); a = sys.argv[1:]
queued = os.environ.pop('ORCH_TEST_TMUX_QUEUED', None)        # one command of a queue already split below
if not queued:
    with (b/'tmux-log').open('a') as f: f.write(json.dumps(a)+'\n')
sock = None; prefix = []
while a[:1] in (['-u'], ['-S']):                                          # -u: UTF-8 output; -S: server socket
    if a[0] == '-u': prefix, a = prefix + a[:1], a[1:]
    else: sock, prefix, a = a[1], prefix + a[:2], a[2:]
# A command queue, as tmux parses argv: an argument ending in ";" ends a command there (a lone ";"
# is just the separator), unless it ends in "\;", which is a literal ";". Each command runs in turn
# against the same server and the queue stops at the first one that fails, as in tmux.
cmds, cur = [], []
for x in ([] if queued else a):
    if x.endswith(';'):
        x = x[:-1]
        if x.endswith('\\'): cur.append(x[:-1] + ';'); continue
        if x: cur.append(x)
        cmds.append(cur); cur = []
    else: cur.append(x)
if cur: cmds.append(cur)
cmds = [a] if queued else [c for c in cmds if c]
if len(cmds) > 1:
    if sum(len(x)+1 for x in sys.argv) > 16384: sys.stderr.write('command too long\n'); sys.exit(1)
    for c in cmds:
        rc = subprocess.call([sys.argv[0], *prefix, *c], env=dict(os.environ, ORCH_TEST_TMUX_QUEUED='1'))
        if rc: sys.exit(rc)
    sys.exit(0)
if cmds: a = cmds[0]
# The socket IS the server: sessions, options and buffers belong to one socket path, and two
# different -S paths are two different servers, as they would be on a real host. No -S means the
# socket tmux itself picks ($TMUX_TMPDIR else /tmp, tmux(1) -L), which is the same server an
# explicit -S naming that path reaches. Keying state on the resolved path instead of discarding
# -S is what makes a disagreement about WHICH server a remote session lives on visible here.
if sock is None: sock = '%s/tmux-%d/default' % (os.environ.get('TMUX_TMPDIR') or '/tmp', os.getuid())
# The state file is named after the resolved socket; the one this machine's scripts use by
# default (ORCH_TEST_DEFAULT_SOCK, set per machine by the harness) keeps the plain name the test
# helpers read. A pane whose TMUX_TMPDIR is redirected to the agent scratch directory therefore
# gets its own server here too, exactly as it would in reality.
tail = '' if sock == os.environ.get('ORCH_TEST_DEFAULT_SOCK') else '-' + hashlib.sha256(sock.encode()).hexdigest()[:8]
state_file = b/('tmux-state%s.json' % tail); buffers_file = b/('tmux-buffers%s.json' % tail)
def load():
    return (json.loads(state_file.read_text()) if state_file.exists() else {},
            json.loads(buffers_file.read_text()) if buffers_file.exists() else {})
state, buffers = load()
def save(): state_file.write_text(json.dumps(state)); buffers_file.write_text(json.dumps(buffers))
def target(i):
    t = a[i]
    if t.startswith('='):
        name = t[1:].rstrip(':')
        if name in state: return name
        sys.stderr.write("can't find session: %s\n" % t); sys.exit(1)
    if t.startswith('%'):                                                 # a pane ID is exact too
        for name, s in state.items():
            if s.get('pane') == t: return name
        sys.stderr.write("can't find pane: %s\n" % t); sys.exit(1)
    sys.stderr.write('mock tmux: non-exact target %s\n' % t); sys.exit(3)   # prefix matching is a bug
def buffer_name(): return a[a.index('-b')+1]
def create(n, path):
    seq = 1 + max([s.get('created', 0) for s in state.values()] + [0])
    state[n] = {'dead': 0, 'options': {}, 'path': path, 'created': seq, 'pane': '%%%d' % (seq + 40), 'id': '$%d' % seq}
def expand(fmt, n, s):
    vals = {'session_name': n, 'session_created': str(s.get('created', 0)), 'session_path': s.get('path', ''),
            'pane_id': s.get('pane', ''), 'session_id': s.get('id', ''),
            'pane_dead': str(s.get('dead', 1)), 'pane_current_command': os.environ.get('TEST_PANE_COMMAND', 'bash'), 'window_activity': '0',
            'pane_current_path': s.get('path', ''), 'pane_title': os.environ.get('TEST_PANE_TITLE', '')}
    return re.sub(r'#\{([^}]+)\}', lambda m: s['options'].get(m.group(1), '') if m.group(1).startswith('@') else vals.get(m.group(1), ''), fmt)
if sum(len(x)+1 for x in sys.argv) > 16384: sys.stderr.write('command too long\n'); sys.exit(1)
c = a[0]
if c == 'has-session':
    t = a[a.index('-t')+1]
    sys.exit(0 if t.startswith('=') and t[1:] in state else 1)
if c == 'show-environment': sys.exit(0)
# A pane's environment is the SERVER's (captured when its first session started) plus respawn-pane -e,
# never the caller's. The mock passes the caller's through so tests can steer the fakes (TEST_*)
# between calls, except for the account selectors CLAUDE_CONFIG_DIR and CODEX_HOME, which follow tmux.
server_env_file = b/('tmux-env%s.json' % tail)
if c == 'new-session':
    n = a[a.index('-s')+1]
    if not state: server_env_file.write_text(json.dumps({k: os.environ.get(k) for k in ('CLAUDE_CONFIG_DIR', 'CODEX_HOME')}))
    # TEST_NEW_SESSION_RACE=<name>[,<name>…]: another creator takes each such name just before this call lands.
    if n in os.environ.get('TEST_NEW_SESSION_RACE', '').split(',') and n not in state: create(n, '/elsewhere'); save()
    if n in state: sys.stderr.write('duplicate session: %s\n' % n); sys.exit(1)
    if '-d' not in a: sys.stderr.write('open terminal failed: not a terminal\n'); sys.exit(1)
    create(n, a[a.index('-c')+1] if '-c' in a else ''); save()
    if '-P' in a: print(expand(a[a.index('-F')+1] if '-F' in a else '#{session_name}:', n, state[n]))
    sys.exit(0)
if c == 'kill-session':
    n = target(a.index('-t')+1)
    if os.environ.get('TEST_KILL_FAIL'): sys.stderr.write('mock tmux: kill-session refused\n'); sys.exit(1)
    del state[n]; save(); sys.exit(0)
if c == 'kill-server': state.clear(); buffers.clear(); save(); sys.exit(0)
if c == 'display-message':
    n = target(a.index('-t')+1) if '-t' in a else None; key = a[-1]; s = state.get(n, {})
    known = {'#S': os.environ.get('TEST_TMUX_SESSION', 'parent'), '#{pane_dead}': str(s.get('dead', 1)), '#{pane_current_path}': s.get('path', ''),
             '#{socket_path}': sock, '#{pane_current_command}': os.environ.get('TEST_PANE_COMMAND', 'claude'),
             '#{pane_pid}': os.environ.get('TEST_PANE_PID', str(os.getpid()))}
    print(known[key] if key in known else expand(key, n, s) if n else ''); sys.exit(0)
if c == 'show-options':
    # Session user option: `show-options -qv -t =name: @tag`. Without -q an unset option is an error.
    n = target(a.index('-t')+1); v = state[n]['options'].get(a[-1])
    quiet = any(f.startswith('-') and 'q' in f for f in a[1:-1])
    if v is None: sys.exit(0 if quiet else 1)
    print(v); sys.exit(0)
if c == 'set-option':
    n = target(a.index('-t')+1)
    if '-u' not in a and a[-2] == os.environ.get('TEST_SET_OPTION_FAIL'): sys.stderr.write('mock tmux: set-option refused\n'); sys.exit(1)
    if '-u' in a: state[n]['options'].pop(a[-1], None)
    else: state[n]['options'][a[-2]] = a[-1]
    save(); sys.exit(0)
if c == 'respawn-pane':
    n = target(a.index('-t')+1)
    if os.environ.get('TEST_RESPAWN_FAIL'): sys.stderr.write('mock respawn failure\n'); sys.exit(1)
    env = os.environ.copy(); cwd = None
    server_env = json.loads(server_env_file.read_text()) if server_env_file.exists() else {}
    for k in ('CLAUDE_CONFIG_DIR', 'CODEX_HOME'):
        env.pop(k, None)
        if server_env.get(k) is not None: env[k] = server_env[k]
    for i, arg in enumerate(a[:a.index('--')]):
        if arg == '-e': k, v = a[i+1].split('=', 1); env[k] = v
        if arg == '-c': cwd = a[i+1]
    rc = subprocess.call(a[a.index('--')+1:], env=env, cwd=cwd)
    state, buffers = load()      # the command may have called this mock itself
    state[n]['dead'] = 0 if os.environ.get('TEST_PANE_ALIVE') else 1; state[n]['status'] = rc; save()
    sys.exit(0)
if c == 'load-buffer':
    if os.environ.get('TEST_LOAD_FAIL'): sys.stderr.write('mock tmux: load refused\n'); sys.exit(1)
    data = sys.stdin.buffer.read().decode(); (b/'buffer').write_text(data)
    if data and '-b' in a: buffers[buffer_name()] = data; save()     # tmux silently drops an empty buffer
    sys.exit(0)
if c == 'show-buffer':
    n = buffer_name()
    if n not in buffers: sys.stderr.write('no buffer %s\n' % n); sys.exit(1)
    sys.stdout.write(buffers[n]); sys.exit(0)
if c == 'delete-buffer':
    n = buffer_name()
    if os.environ.get('TEST_DELETE_FAIL'): sys.stderr.write('mock tmux: server gone\n'); sys.exit(1)
    if n not in buffers: sys.stderr.write('unknown buffer: %s\n' % n); sys.exit(1)
    del buffers[n]; save(); sys.exit(0)
if c == 'paste-buffer':
    target(a.index('-t')+1)
    if os.environ.get('TEST_PASTE_FAIL'): sys.stderr.write('mock tmux: paste refused\n'); sys.exit(1)     # the buffer stays, as in tmux
    if '-d' in a and '-b' in a: buffers.pop(buffer_name(), None); save()
    sys.exit(0)
if c in ('send-keys', 'capture-pane'):
    if c == 'send-keys' and os.environ.get('TEST_SEND_KEYS_FAIL'): sys.stderr.write('mock tmux: submission refused\n'); sys.exit(1)
    if '-t' in a: target(a.index('-t')+1)
    sys.exit(0)
if c in ('list-panes', 'list-sessions', 'ls'):
    if '-f' in a: sys.stderr.write('mock tmux: -f filters need tmux 3.1; match client-side\n'); sys.exit(3)
    fmt = a[a.index('-F')+1] if '-F' in a else '#{session_name}'
    for n, s in state.items(): print(expand(fmt, n, s))
    sys.exit(0)
sys.exit(0)
'''
CLI_MOCK = r'''#!/usr/bin/env python3
import os, sys, json
from pathlib import Path
b = Path(os.environ['ORCH_TEST_TMP']); me = Path(sys.argv[0]).name
keep = ['CODEX_THREAD_ID', 'CLAUDECODE', 'CLAUDE_CODE_CHILD_SESSION', 'CLAUDE_CONFIG_DIR', 'ANTHROPIC_API_KEY', 'CODEX_HOME', 'TMUX', 'TMUX_TMPDIR', 'PROMPT']
env = {k: os.environ.get(k) for k in keep}
env.update({k: v for k, v in os.environ.items() if k.startswith('ORCHESTRA_')})
env['legacy'] = sorted(k for k in os.environ if k.startswith(('PLAYER_', 'ORCHESTRATOR_')))
with (b/'calls').open('a') as f:
    f.write(json.dumps({'cli': me, 'args': sys.argv[1:], 'env': env, 'cwd': os.getcwd()})+'\n')
if me == 'claude' and os.environ.get('TEST_CLAUDE_NOCONV'): print('No conversation found to continue'); sys.exit(1)
sys.exit(int(os.environ.get('TEST_%s_EXIT' % me.upper(), os.environ.get('TEST_CLI_EXIT', '0'))))
'''

# Mock beam: records every invocation's argv (one JSON line per call, to beam-log) and, for
# `exec`, actually runs the given argv (through the same PATH, so it reaches the tmux/git/codex
# mocks) with stdin forwarded byte for byte — this is what lets a single test prove both "the
# same argv reached the target" and "stdin of any size arrived intact" in one step, the way a
# real `beam exec` would. `msg send`/`msg listen`/`status`/`peers` are controlled by the
# TEST_BEAM_* environment variables a test sets before calling the script under test.
BEAM_MOCK = r'''#!/usr/bin/env python3
import os, sys, json, subprocess
from pathlib import Path
b = Path(os.environ['ORCH_TEST_TMP']); a = sys.argv[1:]
def peer_view(pid, label, state, alias=None):
    return {'peerId': pid, 'label': label, 'alias': alias, 'state': state, 'inbound': False, 'path': 'direct',
            'lastSeenAt': 0, 'grant': 'all', 'revokedAt': None, 'pinnedAt': 0, 'queue': {'outbound': 0, 'inbound': 0, 'refused': 0}}
with (b/'beam-log').open('a') as f: f.write(json.dumps(a)+'\n')
if a[:1] == ['exec']:
    machine = a[1]; rest = a[2:]
    dd = a.index('--')
    cwd = a[a.index('--cwd')+1] if '--cwd' in a[:dd] else None
    argv = a[dd+1:]
    stdin_data = sys.stdin.buffer.read()
    (b/'beam-exec-stdin').write_bytes(stdin_data); (b/'beam-exec-machine').write_text(machine)
    # A faked remote must be an observably different place, not just the same host reached a
    # second time: when the caller has set ORCH_TEST_REMOTE_TMP (see enable_remote_machine in the
    # test harness), the argv this call actually runs sees a different ORCH_TEST_TMP (so the tmux
    # and CLI mocks read/write a separate state directory — a separate tmux "server" and a
    # separate call log), a different PATH (so a binary present on one side and absent on the
    # other is testable) and a different HOME. A script that bypasses beam_exec and calls tmux/git
    # bare still runs under THIS process's own (local) environment, so it still lands in the local
    # state directory — which is exactly the distinction the invariant tests below rely on.
    env = os.environ.copy()
    remote_tmp = os.environ.get('ORCH_TEST_REMOTE_TMP')
    if remote_tmp:
        env['ORCH_TEST_TMP'] = remote_tmp
        if os.environ.get('ORCH_TEST_REMOTE_PATH'): env['PATH'] = os.environ['ORCH_TEST_REMOTE_PATH']
        if os.environ.get('ORCH_TEST_REMOTE_HOME'): env['HOME'] = os.environ['ORCH_TEST_REMOTE_HOME']
        # A machine whose tmux keeps its sockets somewhere other than /tmp/tmux-<uid>: the
        # target's own default socket, which only the target can answer for.
        if os.environ.get('ORCH_TEST_REMOTE_TMUX_TMPDIR'):
            env['TMUX_TMPDIR'] = os.environ['ORCH_TEST_REMOTE_TMUX_TMPDIR']
            env['ORCH_TEST_DEFAULT_SOCK'] = '%s/tmux-%d/default' % (env['TMUX_TMPDIR'], os.getuid())
    # TEST_BEAM_EXEC_FAIL=<substring>: the transport itself fails for any argv containing it —
    # the machine could not be reached, which is not an answer about the machine's filesystem.
    fail = os.environ.get('TEST_BEAM_EXEC_FAIL')
    if fail and fail in ' '.join(argv):
        sys.stderr.write('beam: exec %s: peer not connected\n' % machine); sys.exit(1)
    r = subprocess.run(argv, cwd=cwd, input=stdin_data, env=env)
    sys.exit(r.returncode)
if a[:1] == ['status']:
    print(json.dumps({'peerId': os.environ.get('TEST_BEAM_PEER_ID', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
                       'label': os.environ.get('TEST_BEAM_LABEL_SELF', 'thishost'), 'running': True}))
    sys.exit(0)
if a[:1] == ['peers']:
    # Shaped like the real CLI's output: `{ "peers": [PeerView…] }`, indented (beam/docs/06, 07).
    raw = os.environ.get('TEST_BEAM_PEERS_JSON')      # the peers array verbatim, for labels TEST_BEAM_PEERS cannot express
    if raw: print(json.dumps({'peers': json.loads(raw)}, indent=2)); sys.exit(0)
    peers = []
    for item in os.environ.get('TEST_BEAM_PEERS', '').split(','):
        if not item: continue
        parts = item.split(':'); pid = parts[0]
        peers.append(peer_view(pid, parts[1] if len(parts) > 1 else pid, parts[2] if len(parts) > 2 else 'connected'))
    print(json.dumps({'peers': peers}, indent=2)); sys.exit(0)
if a[:2] == ['msg', 'send']:
    # `beam msg send <peer> [--topic T] [--base64] <payload|->`, and nothing else: the real CLI has
    # no --json here and exits 2 on any flag it does not know (beam/docs/07-cli.md).
    peer = a[2]; rest = a[3:]
    if len(rest) != 3 or rest[:2] != ['--topic', 'orchestra'] or any(x.startswith('--') and x != '--topic' for x in rest):
        sys.stderr.write('usage: beam msg send <peer> [--topic T] [--base64] <payload|->\n'); sys.exit(2)
    stdin_data = sys.stdin.buffer.read().decode() if rest[2] == '-' else rest[2]
    with (b/'beam-sent').open('a') as f: f.write(json.dumps({'peer': peer, 'payload': stdin_data})+'\n')
    outcome = os.environ.get('TEST_BEAM_OUTCOME', 'delivered')
    if outcome == 'delivered': print('delivered to %s' % peer); sys.exit(0)
    if outcome == 'stored-offline':
        print('stored for %s; delivery pending (%s is offline). beam will deliver it when %s connects. Do not send it again.' % (peer, peer, peer)); sys.exit(0)
    if outcome == 'stored-no-ack':
        print('stored for %s; delivery pending (%s has not acknowledged it). beam will keep delivering it until %s does. Do not send it again.' % (peer, peer, peer)); sys.exit(0)
    sys.stderr.write('rejected: %s\n' % os.environ.get('TEST_BEAM_REJECT_REASON', 'unknown-peer')); sys.exit(1)
sys.exit(0)
'''

# Fake beam daemon for relay.sh: the control socket's subscriber side, over a real AF_UNIX socket
# at $BEAM_SOCKET (beam/docs/06-control-socket.md). Requests are one JSON object per line with
# the parameters beside "op"; replies are {id, ok, result|error}; after msg.subscribe each
# envelope in beam-inbox (one per line) goes out as {"event":"mail","data":<envelope>}, one at a
# time, the next only once the previous is settled by msg.ack or msg.defer — or never, if the
# subscriber does neither. A new connection (a later subscription) is offered every envelope not
# yet acked, deferred ones included. When nothing is left to offer it holds the connection for
# BEAMD_HOLD seconds, then closes it; it serves BEAMD_CONNECTIONS connections, then exits.
# Every request is appended to beamd-log as {"conn": n, "req": {...}}.
BEAMD = r'''#!/usr/bin/env python3
import os, sys, json, socket, time, select
from pathlib import Path
b = Path(os.environ['ORCH_TEST_TMP']); path = os.environ['BEAM_SOCKET']
inbox = [l for l in (b/'beam-inbox').read_text().splitlines() if l] if (b/'beam-inbox').exists() else []
acked = set(); hold = float(os.environ.get('BEAMD_HOLD', '0')); refuse = os.environ.get('BEAMD_REFUSE_SUBSCRIBE')
srv = socket.socket(socket.AF_UNIX); srv.bind(path); srv.listen(1); (b/'beamd-ready').write_text('')
def log(n, req):
    with (b/'beamd-log').open('a') as f: f.write(json.dumps({'conn': n, 'req': req})+'\n')
for n in range(1, int(os.environ.get('BEAMD_CONNECTIONS', '1')) + 1):
    srv.settimeout(20)
    try: conn, _ = srv.accept()
    except socket.timeout: break
    buf = b''; queue = []; inflight = None; idle_since = None; closed = False
    def send(obj): conn.sendall(json.dumps(obj, separators=(',', ':'), ensure_ascii=False).encode()+b'\n')
    while not closed:
        if inflight is None and not queue and idle_since is not None and time.time() - idle_since >= hold: break
        r, _, _ = select.select([conn], [], [], 0.1)
        if not r: continue
        data = conn.recv(1 << 20)
        if not data: break
        buf += data
        while b'\n' in buf:
            line, buf = buf.split(b'\n', 1)
            req = json.loads(line); log(n, req); op = req.get('op')
            if op == 'msg.subscribe':
                if refuse: send({'id': req['id'], 'ok': False, 'error': refuse}); closed = True; break
                send({'id': req['id'], 'ok': True, 'result': {}})
                queue = [e for e in inbox if json.loads(e)['id'] not in acked]; idle_since = time.time()
            elif op in ('msg.ack', 'msg.defer'):
                if inflight is None or json.loads(inflight)['id'] != req.get('envelopeId'):
                    send({'id': req['id'], 'ok': False, 'error': 'params', 'detail': 'not in flight'}); continue
                if op == 'msg.ack': acked.add(req['envelopeId'])
                inflight = None; send({'id': req['id'], 'ok': True, 'result': {}}); idle_since = time.time()
            else:
                send({'id': req['id'], 'ok': False, 'error': 'params'})
            if inflight is None and queue:
                inflight = queue.pop(0); send({'event': 'mail', 'data': json.loads(inflight)})
    if closed: time.sleep(0.2)
    conn.close()
srv.close(); os.unlink(path)
'''

class PortTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='orch-test.')
        self.base = Path(self.tmp.name); self.repo = self.base/'repo'; self.repo.mkdir(); self.bin = self.base/'bin'; self.bin.mkdir()
        self.env = {k: v for k, v in os.environ.items() if not k.startswith(('CLAUDE', 'CODEX', 'ORCHESTRA', 'TMUX', 'ANTHROPIC', 'PLAYER'))}
        self.env.update(PATH=str(self.bin)+':'+self.env['PATH'], CODEX_THREAD_ID=ID, CODEX_SESSION_ID=ID, ORCH_TEST_TMP=str(self.base),
                        CODEX_HOME=str(self.base/'codex-home'), CLAUDE_CONFIG_DIR=str(self.base/'claude-config'),
                        ORCH_TEST_DEFAULT_SOCK='/tmp/tmux-%d/default' % os.getuid())
        self.git_init(self.repo)
        self.stub('tmux', TMUX_MOCK); self.stub('codex', CLI_MOCK); self.stub('claude', CLI_MOCK)
        # A beam installed on the machine running the tests must not answer for the fake machines
        # here (sessions.sh --all would list its real peers): by default beam is a stub that fails
        # every command, which tests that need beam replace with BEAM_MOCK.
        self.stub('beam', '#!/bin/sh\necho "beam: not available in this test" >&2\nexit 1\n')
        self.wt = self.repo/'.claude/worktrees/feature-test'
        self.session = 'repo-feature-test'                     # sanitize(basename(repo)) + "-" + sanitize(branch)
        self.sock = '/tmp/tmux-%d/default' % os.getuid()      # spawn.sh's default server when TMUX is unset
    def tearDown(self): self.tmp.cleanup()
    def git_init(self, path):
        path.mkdir(parents=True, exist_ok=True)
        self.run_cmd(['git', 'init', '-q', str(path)], cwd=self.base)
        self.run_cmd(['git', '-c', 'user.name=Test', '-c', 'user.email=test@example.invalid', 'commit', '--allow-empty', '-qm', 'initial'], cwd=path)
    def stub(self, name, text, in_dir=None): p = (in_dir or self.bin)/name; p.write_text(text); p.chmod(0o755)
    def enable_remote_machine(self):
        # Gives beam's exec a genuinely separate place to land, per BEAM_MOCK above: its own tmux
        # server (state/log/buffers all keyed off a different ORCH_TEST_TMP), its own PATH (so a
        # binary present on one side and absent on the other is testable) and its own HOME. A
        # script that still calls tmux/git bare instead of through tmux_on/g/r/beam_exec keeps
        # landing in THIS machine's state (self.state()/self.calls()), never the remote one — that
        # gap is what the invariant tests below assert on.
        self.remote = self.base/'remote'; self.remote_bin = self.remote/'bin'; self.remote_home = self.remote/'home'
        self.remote_bin.mkdir(parents=True); self.remote_home.mkdir(parents=True)
        self.stub('tmux', TMUX_MOCK, in_dir=self.remote_bin); self.stub('codex', CLI_MOCK, in_dir=self.remote_bin); self.stub('claude', CLI_MOCK, in_dir=self.remote_bin)
        self.stub('beam', BEAM_MOCK)   # only the local side ever invokes `beam`
        system_path = ':'.join(p for p in self.env['PATH'].split(':') if p != str(self.bin))
        self.env['ORCH_TEST_REMOTE_TMP'] = str(self.remote)
        self.env['ORCH_TEST_REMOTE_PATH'] = str(self.remote_bin)+':'+system_path
        self.env['ORCH_TEST_REMOTE_HOME'] = str(self.remote_home)
        # The plugin is installed at the same $HOME-relative path on both sides (Claude Code's
        # plugin cache): ~/skills/orchestrator/scripts/_launch.sh here and on the remote.
        self.env['HOME'] = str(ROOT.parent); (self.remote_home/'skills').symlink_to(ROOT)
    def remote_state(self):
        f = self.remote/'tmux-state.json'
        return json.loads(f.read_text()) if f.exists() else {}
    def remote_calls(self):
        f = self.remote/'calls'
        return [json.loads(x) for x in f.read_text().splitlines()] if f.exists() else []
    def run_cmd(self, args, cwd=None, ok=True, env=None, stdin=None):
        # No input means an empty stdin, never the runner's own: the beam mock's exec forwards stdin
        # to EOF, which an inherited terminal or socket would never reach.
        x = subprocess.run(args, cwd=cwd or self.repo, env=env or self.env, text=True, capture_output=True, input=stdin or '')
        if ok: self.assertEqual(x.returncode, 0, x.stderr+'\n'+x.stdout)
        return x
    def script(self, name): return str(ROOT/('player/scripts/report.sh' if name == 'report.sh' else 'orchestrator/scripts/'+name))
    def spawn(self, *extra, ok=True, prompt=True, repo=None, branch='feature/test'):
        p = ['--prompt', "Task with $player, 'quotes', `touch BAD`, $(touch BAD), and\na newline END-OF-TASK"] if prompt else []
        return self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(repo or self.repo), '--branch', branch, '--from', 'HEAD', *p, '--no-node-modules', *extra], ok=ok)
    def orch(self, name, *args, ok=True, cwd=None):
        return self.run_cmd(['bash', self.script(name), *args], ok=ok, cwd=cwd)
    def calls(self):
        f = self.base/'calls'
        return [json.loads(x) for x in f.read_text().splitlines()] if f.exists() else []
    def tmux_log(self):
        f = self.base/'tmux-log'
        return f.read_text() if f.exists() else ''
    def tmux_calls(self): return [json.loads(l) for l in self.tmux_log().splitlines()]
    # Each tmux call is a command queue: its commands, without the -u/-S prefix, split the way
    # tmux splits argv (an element ending in ";" ends a command; "\\;" is a literal ";").
    @staticmethod
    def queue(call):
        i = 0
        while call[i:i+1] in (['-u'], ['-S']): i += 1 if call[i] == '-u' else 2
        cmds, cur = [], []
        for x in call[i:]:
            if x.endswith(';') and not x.endswith('\\;'):
                if x[:-1]: cur.append(x[:-1])
                cmds.append(cur); cur = []
            else: cur.append(x[:-2] + ';' if x.endswith('\\;') else x)
        if cur: cmds.append(cur)
        return [c for c in cmds if c]
    def tmux_commands(self): return [c for call in self.tmux_calls() for c in self.queue(call)]
    def pane(self, session=None, sock=None): return self.state(sock)[session or self.session]['pane']
    def clear_log(self): (self.base/'tmux-log').unlink()
    def beam_calls(self):
        f = self.base/'beam-log'
        return [json.loads(l) for l in f.read_text().splitlines()] if f.exists() else []
    def beam_sent(self):
        f = self.base/'beam-sent'
        return [json.loads(l) for l in f.read_text().splitlines()] if f.exists() else []
    def run_relay(self, *args, envelopes=(), env=None, ok=True, **beamd):
        # relay.sh against BEAMD on a real socket; returns (result, [(conn, request)…]).
        import time
        (self.base/'beam-inbox').write_text(''.join(json.dumps(e)+'\n' for e in envelopes))
        self.stub('beamd', BEAMD); self.stub('beam', BEAM_MOCK)
        env = dict(env or self.env, BEAM_SOCKET=str(self.base/'beam.sock'), **{k.upper(): str(v) for k, v in beamd.items()})
        d = subprocess.Popen([str(self.bin/'beamd')], env=env)
        try:
            for _ in range(100):
                if (self.base/'beamd-ready').exists(): break
                time.sleep(0.05)
            x = self.run_cmd(['bash', self.script('relay.sh'), *args], cwd=self.base, env=env, ok=ok)
        finally:
            d.wait(timeout=30)
        f = self.base/'beamd-log'
        log = [json.loads(l) for l in f.read_text().splitlines()] if f.exists() else []
        return x, [(e['conn'], e['req']) for e in log]
    def settled(self, log, op): return [r.get('envelopeId') for _, r in log if r.get('op') == op]
    # One state file per tmux server, named after its socket (see TMUX_MOCK): sock selects which
    # server a helper reads or writes, defaulting to the one the scripts use with no socket given.
    def state_file(self, sock=None, base=None):
        base = self.base if base is None else base
        tail = '' if sock in (None, self.sock) else '-' + hashlib.sha256(sock.encode()).hexdigest()[:8]
        return base/('tmux-state%s.json' % tail)
    def state(self, sock=None): return json.loads(self.state_file(sock).read_text())
    def buffers(self):
        f = self.base/'tmux-buffers.json'
        return json.loads(f.read_text()) if f.exists() else {}
    def tag(self, name, session=None, sock=None): return self.state(sock)[session or self.session]['options'].get(name)
    def last_report(self, sock=None):
        v = self.tag('@session-x-orchestra-last-report', sock=sock); self.assertIsNotNone(v, '@session-x-orchestra-last-report is unset'); return v
    def set_state(self, s, sock=None): self.state_file(sock).write_text(json.dumps(s))
    def drop_tag(self, name): self.drop_tag_of(self.session, name)
    def set_tag(self, name, value, session=None):        # a value no resumable harness has, say
        s = self.state(); s[session or self.session]['options'][name] = value; self.set_state(s)
    def drop_tag_of(self, session, name):
        s = self.state(); s[session]['options'].pop(name, None); self.set_state(s)
    def rename(self, old, new, sock=None):
        s = self.state(sock); s[new] = s.pop(old); self.set_state(s, sock)
    # A session some other program created: no tags unless given (mock tmux, so any name works).
    # sock plants it on another server, the way a session reached through a different $TMUX or
    # ORCHESTRA_SOCKET really would live on one.
    def foreign(self, name, tags=None, sock=None):
        pre = [] if sock is None else ['-S', sock]
        self.run_cmd(['tmux', *pre, 'new-session', '-d', '-s', name])
        for k, v in (tags or {}).items(): self.run_cmd(['tmux', *pre, 'set-option', '-t', '='+name+':', k, v])
    # A worktree session's record as its launcher writes it (n10 by default), version last.
    def player_tags(self, repo=None, branch='feature/test', launcher='n10', agent='claude'):
        root = (repo or self.repo).resolve(); wt = str(root/'.claude/worktrees'/branch.replace('/', '-'))
        return {'@session-agent': agent, '@session-launcher': launcher, '@session-pane': '%7', '@session-repo': str(root),
                '@session-worktree': wt, '@session-cwd': wt, '@session-x-%s-branch' % launcher: branch,
                '@session-x-%s-session-type' % launcher: 'worktree', '@session-version': '1'}
    # An n10 terminal tab running a shell: vendor data only, no record.
    def shell_tab_tags(self, d=None): return {'@session-x-n10-session-type': 'shell', '@session-x-n10-dir': str(d or self.repo.resolve())}
    def sessions(self, *args): return json.loads(self.orch('sessions.sh', '--json', *args).stdout)
    # Environment of a process inside the player's pane: what spawn.sh injects through respawn-pane -e.
    def player_env(self, **extra):
        env = dict(self.env, ORCHESTRA_SESSION=self.session, ORCHESTRA_SOCKET=self.sock); env.update(extra); return env
    def report(self, *args, ok=True, cwd=None, env=None): return self.run_cmd(['bash', self.script('report.sh'), *args], ok=ok, cwd=cwd or self.wt, env=env or self.player_env())
    def gitdir(self): return Path(self.run_cmd(['git', 'rev-parse', '--absolute-git-dir'], cwd=self.wt).stdout.strip())
    def rollout(self, cwd, uuid=UUID, stamp='2026-09-13T10-00-00'):
        d = self.base/'codex-home/sessions/2026/09/13'; d.mkdir(parents=True, exist_ok=True)
        (d/('rollout-%s-%s.jsonl' % (stamp, uuid))).write_text(json.dumps({'type': 'session_meta', 'payload': {'id': uuid, 'cwd': cwd}})+'\n')
    def kill_pane(self, session=None):
        s = self.state(); s[session or self.session]['dead'] = 1; self.set_state(s)
    def assert_no_state_files(self):
        for f in ('player-orchestrator', 'player-prompt', 'player-agent'): self.assertFalse((self.gitdir()/f).exists(), f)
        self.assertFalse((self.base/'mail').exists())
        self.assertEqual([p.name for p in self.gitdir().glob('player-*')], [])
    def lib(self, snippet, *args, ok=True):      # a snippet run with _lib.sh sourced ($0 must be one of its scripts)
        return self.run_cmd(['bash', '-c', '. "$0"; '+snippet, self.script('_lib.sh'), *args], cwd=self.base, ok=ok).stdout

    # --- fresh launches -------------------------------------------------------------
    def test_codex_spawn_prompt_and_isolation(self):
        self.spawn('--agent', 'codex'); c = self.calls()[-1]
        self.assertEqual(c['args'][:4], ['-m', 'gpt-6-sol', '-c', 'model_reasoning_effort="medium"'])
        self.assertTrue(c['args'][-1].startswith('$player Task with $player,'), c['args'][-1])
        self.assertIn('$(touch BAD)', c['args'][-1]); self.assertTrue(c['args'][-1].endswith('\na newline END-OF-TASK')); self.assertFalse((self.wt/'BAD').exists())
        self.assertNotIn('reporting target', c['args'][-1])
        self.assertIsNone(c['env']['CODEX_THREAD_ID']); self.assertEqual(c['env']['legacy'], [])
        self.assertEqual(c['env']['ORCHESTRA_SESSION'], self.session); self.assertEqual(c['env']['ORCHESTRA_SOCKET'], self.sock)
        self.assertNotIn('ORCHESTRA_PLAYER', c['env']); self.assertEqual(c['env']['ORCHESTRA_MODE'], 'fresh'); self.assertEqual(c['env']['ORCHESTRA_HARNESS'], 'codex')
        self.assertEqual(c['env']['TMUX_TMPDIR'], '/tmp/orchestra-agent-tmux'); self.assertIsNone(c['env']['TMUX'])
        self.assertEqual(self.state()[self.session]['options'], {
            'status': 'off', 'remain-on-exit': 'on', '@session-version': '1', '@session-agent': 'codex', '@session-launcher': 'orchestra', '@session-pane': self.pane(),
            '@session-repo': str(self.repo.resolve()), '@session-worktree': str(self.wt.resolve()), '@session-cwd': str(self.wt.resolve()),
            '@session-x-orchestra-session-type': 'worktree', '@session-x-orchestra-branch': 'feature/test',
            '@session-x-orchestra-orchestrator': 'codex:'+ID})
        self.assertRegex(self.pane(), r'^%\d+$')
        self.assertEqual(self.buffers(), {})            # the prompt buffer was consumed by the launcher
        self.assertIn('"orchestra-prompt-%s"' % self.session, self.tmux_log())
        self.assert_no_state_files()
    def test_claude_fable_and_explicit_tmux(self):
        self.spawn('--agent', 'claude', '--model', 'fable', '--orchestrator', 'tmux:parent')
        c = self.calls()[-1]; self.assertEqual(c['args'][:4], ['--model', 'fable', '--effort', 'high'])
        self.assertTrue(c['args'][-1].startswith(INV+' Task with')); self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'tmux:parent')
    def test_standalone_claude_override_spawn_resume_and_adopt(self):
        self.env['ORCHESTRA_CLAUDE_SKILL'] = '/player'
        self.spawn('--agent', 'claude')
        self.assertTrue(self.calls()[-1]['args'][-1].startswith('/player Task with'))
        self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--resume', '--agent', 'claude', prompt=False)
        self.assertTrue(self.calls()[-1]['args'][-1].startswith('/player '+RESTART))
        self.orch('adopt.sh', self.session, '--agent', 'claude', '--orchestrator', 'tmux:new-parent')
        self.assertIn('"-l", "/player"]', self.tmux_log())
    def test_claude_default_adopt_from_either_installation(self):
        self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'claude')
        self.orch('adopt.sh', self.session, '--agent', 'claude', '--orchestrator', 'tmux:new-parent')
        self.assertIn('"-l", "'+INV+'"]', self.tmux_log())
    def claude_config(self, projects):
        cfg = self.base/'claude-config/.claude.json'; cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(json.dumps({'numStartups': 7, 'projects': projects}, indent=2)); cfg.chmod(0o600)
        return cfg
    def test_claude_launch_pre_accepts_trust_and_keeps_mcp_servers(self):
        cfg = self.claude_config({'/elsewhere': {'hasTrustDialogAccepted': False, 'mcpServers': {}}})
        self.spawn('--agent', 'claude'); c = self.calls()[-1]
        self.assertNotIn('--strict-mcp-config', c['args']); self.assertTrue(c['args'][-1].startswith(INV+' Task with'))
        data = json.loads(cfg.read_text())
        self.assertIs(data['projects'][str(self.wt)]['hasTrustDialogAccepted'], True)
        self.assertEqual(data['numStartups'], 7); self.assertEqual(data['projects']['/elsewhere'], {'hasTrustDialogAccepted': False, 'mcpServers': {}})
        self.assertEqual(cfg.stat().st_mode & 0o777, 0o600)
        self.assertEqual(sorted(x.name for x in cfg.parent.iterdir() if x.name.startswith('.claude.json')), ['.claude.json'])   # replaced, no temp left
        self.orch('kill.sh', self.session); self.spawn('--resume', '--agent', 'claude', prompt=False)
        self.assertNotIn('--strict-mcp-config', self.calls()[-1]['args'])
    def test_claude_trust_is_written_for_the_worktree_itself_and_only_once(self):
        # A trusted ancestor is not enough for Claude (a trusted /tmp still prompts below it).
        cfg = self.claude_config({str(self.repo): {'hasTrustDialogAccepted': True}, '/': {'hasTrustDialogAccepted': True}})
        self.spawn('--agent', 'claude'); self.assertIs(json.loads(cfg.read_text())['projects'][str(self.wt)]['hasTrustDialogAccepted'], True)
        before = cfg.read_bytes(); self.orch('kill.sh', self.session); self.spawn('--resume', '--agent', 'claude', prompt=False)
        self.assertEqual(cfg.read_bytes(), before)                                          # already there: nothing rewritten
        cfg.unlink(); self.orch('kill.sh', self.session); self.spawn('--resume', '--agent', 'claude', prompt=False)
        self.assertFalse(cfg.exists())                                                      # never creates Claude's config
    def test_codex_launch_leaves_claude_config_alone(self):
        cfg = self.claude_config({}); before = cfg.read_bytes()
        self.spawn('--agent', 'codex'); self.assertEqual(cfg.read_bytes(), before); self.assertNotIn('--strict-mcp-config', self.calls()[-1]['args'])
    def test_codex_gpt6_models_default_medium_effort(self):
        self.spawn('--agent', 'codex', '--model', 'gpt-6-astra')
        self.assertEqual(self.calls()[-1]['args'][:4], ['-m', 'gpt-6-astra', '-c', 'model_reasoning_effort="medium"'])
    def test_codex_other_models_default_high_effort(self):
        self.spawn('--agent', 'codex', '--model', 'gpt-5.6-sol')
        self.assertEqual(self.calls()[-1]['args'][:4], ['-m', 'gpt-5.6-sol', '-c', 'model_reasoning_effort="high"'])
    def test_sol_override(self):
        self.spawn('--agent', 'codex', '--model', 'gpt-5.6-sol', '--effort', 'xhigh'); self.assertEqual(self.calls()[-1]['args'][3], 'model_reasoning_effort="xhigh"')
    def test_custom_harness_tag(self):
        self.spawn('--cmd', 'claude "$PROMPT"'); c = self.calls()[-1]
        self.assertTrue(c['args'][-1].startswith(INV+' Task with')); self.assertEqual(self.tag('@session-agent'), 'custom')
    def test_env_markers_stripped_config_kept(self):
        self.env.update(CLAUDECODE='1', CLAUDE_CODE_CHILD_SESSION='1', ANTHROPIC_API_KEY='secret', TMUX='')
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); e = self.calls()[-1]['env']
        self.assertIsNone(e['CLAUDECODE']); self.assertIsNone(e['CLAUDE_CODE_CHILD_SESSION']); self.assertIsNone(e['CODEX_THREAD_ID'])
        self.assertEqual(e['CLAUDE_CONFIG_DIR'], str(self.base/'claude-config')); self.assertEqual(e['ANTHROPIC_API_KEY'], 'secret'); self.assertEqual(e['CODEX_HOME'], str(self.base/'codex-home'))
    def test_orchestrator_claude_config_dir_reaches_a_local_player(self):
        # The server is already running, started from a shell on the default account: respawn-pane
        # hands the pane that server's environment, so the orchestrator's own account has to be passed.
        mine = str(self.base/'claude-config')
        self.run_cmd(['tmux', 'new-session', '-d', '-s', 'user-shell'], env=dict(self.env, CLAUDE_CONFIG_DIR=str(self.base/'other-account')))
        self.spawn('--agent', 'claude'); self.assertEqual(self.calls()[-1]['env']['CLAUDE_CONFIG_DIR'], mine)
        self.kill_pane(); self.spawn('--resume', prompt=False); self.assertEqual(self.calls()[-1]['env']['CLAUDE_CONFIG_DIR'], mine)
        # An orchestrator on the default account gets a player on the default account too.
        del self.env['CLAUDE_CONFIG_DIR']; self.kill_pane(); self.spawn('--resume', prompt=False)
        self.assertIsNone(self.calls()[-1]['env']['CLAUDE_CONFIG_DIR'])
    def test_orchestrator_codex_home_reaches_a_local_player(self):
        # As for Claude above: the server started under another Codex home, and the player must
        # run, and look for conversations to resume, under the orchestrator's.
        mine = str(self.base/'codex-home')
        self.run_cmd(['tmux', 'new-session', '-d', '-s', 'user-shell'], env=dict(self.env, CODEX_HOME=str(self.base/'other-codex')))
        self.spawn('--agent', 'codex'); self.assertEqual(self.calls()[-1]['env']['CODEX_HOME'], mine)
        self.kill_pane(); self.rollout(str(self.wt.resolve())); self.spawn('--resume', prompt=False)
        self.assertEqual(self.calls()[-1]['args'][:2], ['resume', UUID]); self.assertEqual(self.calls()[-1]['env']['CODEX_HOME'], mine)
        del self.env['CODEX_HOME']; self.spawn('--agent', 'codex', branch='feature/two')      # the default home, not the server's
        self.assertIsNone(self.calls()[-1]['env']['CODEX_HOME'])
    def test_large_prompt_and_failed_launch_retry(self):
        big = 'x'*40000; pf = self.base/'task.txt'; pf.write_text('Task: '+big+'\nEND')
        self.orch('spawn.sh', '--repo', str(self.repo), '--branch', 'feature/test', '--from', 'HEAD', '--prompt-file', str(pf), '--no-node-modules', '--agent', 'claude')
        self.assertTrue(self.calls()[-1]['args'][-1].endswith(big+'\nEND'))
        self.env['TEST_RESPAWN_FAIL'] = '1'
        x = self.spawn('--prompt', 'p', prompt=False, branch='feature/two', ok=False)
        self.assertNotEqual(x.returncode, 0); self.assertIn('placeholder session removed', x.stderr)
        self.assertNotIn('repo-feature-two', self.state()); self.assertEqual(self.buffers(), {})
        del self.env['TEST_RESPAWN_FAIL']
        self.spawn('--prompt', 'p', prompt=False, branch='feature/two')
        self.assertEqual(self.calls()[-1]['cli'], 'claude'); self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], 'repo-feature-two')
    def test_refuses_running_session(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn()
        x = self.spawn(ok=False); self.assertIn('running', x.stderr)
        x = self.spawn('--resume', ok=False); self.assertIn('running', x.stderr)
    def test_dry_run_and_empty_json(self):
        x = self.spawn('--agent', 'codex', '--dry-run'); self.assertFalse((self.repo/'.claude').exists()); self.assertFalse((self.base/'tmux-state.json').exists())
        self.assertRegex(x.stdout, r'(?m)^tmux +repo-feature-test ')          # the label it would get
        x = self.orch('sessions.sh', '--all', '--json'); self.assertEqual(json.loads(x.stdout), [])

    # --- dir players: no branch, no worktree ------------------------------------------
    def dir_spawn(self, path, *extra, ok=True, prompt='Tidy $(touch BAD) up'):
        p = ['--prompt', prompt] if prompt else []
        return self.run_cmd(['bash', self.script('spawn.sh'), '--dir', str(path), *p, *extra], ok=ok, cwd=self.base)
    def notes_dir(self):
        d = self.base/'real/notes'; d.mkdir(parents=True, exist_ok=True); link = self.base/'notes-link'
        if not link.exists(): link.symlink_to(d)
        return link                                                       # a symlink: the tag and label come from the resolved path
    def test_dir_player_spawn_tags_and_refusals(self):
        d = self.notes_dir(); real = str(d.resolve())
        x = self.dir_spawn(d, '--agent', 'codex', '--dry-run'); self.assertRegex(x.stdout, r'(?m)^dir +%s$' % re.escape(real))
        self.assertRegex(x.stdout, r'(?m)^tmux +notes-dir '); self.assertFalse((self.base/'tmux-state.json').exists())
        x = self.dir_spawn(d, '--agent', 'codex'); c = self.calls()[-1]
        self.assertRegex(x.stdout, r'(?m)^started +notes-dir$'); self.assertEqual(c['cwd'], real); self.assertEqual(c['env']['ORCHESTRA_SESSION'], 'notes-dir')
        self.assertTrue(c['args'][-1].startswith('$player Tidy $(touch BAD) up')); self.assertFalse((d/'BAD').exists())
        self.assertEqual(self.state()['notes-dir']['options'], {
            'status': 'off', 'remain-on-exit': 'on', '@session-version': '1', '@session-agent': 'codex', '@session-launcher': 'orchestra',
            '@session-pane': self.pane('notes-dir'), '@session-cwd': real, '@session-x-orchestra-session-type': 'dir',
            '@session-x-orchestra-orchestrator': 'codex:'+ID})
        self.assertEqual(sorted(p.name for p in d.iterdir()), [])      # no worktree, no .claude, nothing written there
        s = self.state(); s['notes-dir']['dead'] = 0; self.set_state(s)
        self.assertIn('running: notes-dir', self.dir_spawn(d, ok=False).stderr)
        for extra in (('--branch', 'feature/x'), ('--repo', str(self.repo)), ('--from', 'HEAD')):
            x = self.dir_spawn(d, *extra, ok=False); self.assertEqual(x.returncode, 2, extra); self.assertIn('--dir', x.stderr)
        n = len(self.tmux_calls())
        x = self.dir_spawn(self.base/'missing', ok=False); self.assertEqual(x.returncode, 1); self.assertIn('missing', x.stderr)
        self.assertEqual([c for c in self.tmux_calls()[n:] if 'new-session' in c], [])
        self.assertEqual(self.lib('session_label "$1" dir', '/x/my.dir'), 'my-dir-dir')
    def test_dir_player_is_addressed_by_its_session_name(self):
        self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'codex')                                    # a worktree player, and a reviewer in its worktree
        self.dir_spawn(self.wt, '--agent', 'codex'); rev = 'feature-test-dir'
        self.assertEqual(self.tag('@session-x-orchestra-session-type', rev), 'dir'); self.assertIsNone(self.tag('@session-x-orchestra-branch', rev)); self.assertIsNone(self.tag('@session-worktree', rev))
        self.dir_spawn(self.repo, '--agent', 'codex', prompt='review')     # one at the repo root
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], 'repo-dir')
        rows = {r['session']: r for r in self.sessions('--all')}
        self.assertEqual(sorted(rows), sorted([self.session, rev, 'repo-dir']))
        self.assertEqual((rows[rev]['repo'], rows[rev]['branch']), (str(self.wt.resolve()), ''))
        self.assertEqual(sorted(r['session'] for r in self.sessions('--repo', str(self.repo))), sorted([self.session, 'repo-dir']))   # repo scope: the tag equals the root
        text = self.orch('sessions.sh', '--all').stdout; self.assertIn(rev, text)
        self.clear_log(); self.orch('send.sh', 'feature/test', '--repo', str(self.repo), 'hi')                 # the branch still names the worktree player
        self.assertIn('"=%s:"' % self.session, self.tmux_log()); self.assertNotIn('"=%s:"' % rev, self.tmux_log())
        self.report('PROGRESS', 'reviewed', env=self.player_env(ORCHESTRA_SESSION=rev), cwd=self.base)
        self.assertEqual(self.calls()[-1]['args'][:5], ['queue', '--thread', ID, '--message', '[player %s] PROGRESS: reviewed' % rev])
        self.assertRegex(self.tag('@session-x-orchestra-last-report', rev), '^PROGRESS '+STAMP+' delivered$')
        for args in (('send.sh', rev, 'hi'), ('screen.sh', rev), ('adopt.sh', rev, '--orchestrator', 'tmux:new-parent')):
            self.clear_log(); self.orch(*args, cwd=self.base); self.assertIn('"=%s:"' % rev, self.tmux_log(), args)
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator', rev), 'tmux:new-parent')
        self.assertIn('running: %s' % rev, self.dir_spawn(self.wt, ok=False).stderr)                           # found by its tags
        self.assertIn('running: %s' % self.session, self.spawn(ok=False).stderr)
        self.orch('kill.sh', rev, cwd=self.base); self.assertEqual(sorted(self.state()), sorted([self.session, 'repo-dir']))
    def test_a_slash_free_branch_never_resolves_to_the_reviewer_in_its_worktree(self):
        # The reviewer's directory is the worktree .claude/worktrees/fix-login, so a label of the bare
        # basename would equal the branch, and an exact-name match would win over the branch.
        self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'codex', branch='fix-login'); self.dir_spawn(self.repo/'.claude/worktrees/fix-login', '--agent', 'codex')
        self.orch('kill.sh', 'fix-login', '--repo', str(self.repo))
        self.assertEqual(sorted(self.state()), ['fix-login-dir'])
    def test_dir_player_resume_continues_its_own_claude_conversation(self):
        d = self.notes_dir(); real = str(d.resolve())
        self.dir_spawn(d, '--agent', 'claude'); c = self.calls()[-1]
        pin = self.tag('@session-x-orchestra-claude-session', 'notes-dir'); self.assertRegex(pin or '', r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')
        self.assertEqual(c['args'][:2], ['--session-id', pin]); self.assertTrue(c['args'][-1].startswith(INV+' Tidy'))
        self.dir_spawn(d, '--resume', prompt=False); c = self.calls()[-1]
        self.assertEqual(c['args'][:2], ['--resume', pin]); self.assertNotIn('--continue', c['args'])       # never "the newest conversation here"
        self.assertTrue(c['args'][-1].startswith(INV+' Your session was restarted in this directory;'), c['args'][-1])
        self.assertEqual(self.tag('@session-x-orchestra-claude-session', 'notes-dir'), pin)
        # A dead pane whose record is gone (dropped here by hand) refuses in the launcher, pane kept.
        self.drop_tag_of('notes-dir', '@session-x-orchestra-claude-session'); n = len(self.calls()); self.dir_spawn(d, '--resume', prompt=False)
        self.assertEqual(self.calls()[n:], []); self.assertEqual((self.state()['notes-dir']['dead'], self.state()['notes-dir']['status']), (1, 1))
        # kill.sh ends the session and the record of its conversation: a later Claude or auto --resume
        # refuses before creating anything, as a worktree resume does without its worktree.
        self.orch('kill.sh', 'notes-dir', cwd=self.base); n = len(self.tmux_calls())
        for extra in ((), ('--agent', 'claude')):
            x = self.dir_spawn(d, '--resume', *extra, prompt=False, ok=False)
            self.assertEqual(x.returncode, 1, extra); self.assertIn('no Claude conversation is recorded', x.stderr)
        self.assertNotIn('notes-dir', self.state()); self.assertEqual([c for c in self.tmux_calls()[n:] if 'new-session' in c], [])
        # Codex: the newest conversation recorded for that directory, even once the session is gone
        self.dir_spawn(d, '--agent', 'codex'); self.orch('kill.sh', 'notes-dir', cwd=self.base); self.rollout(real)
        self.dir_spawn(d, '--resume', '--agent', 'codex', prompt=False); self.assertEqual(self.calls()[-1]['args'][:2], ['resume', UUID])
        self.assertEqual(self.tag('@session-x-orchestra-session-type', 'notes-dir'), 'dir')
    def test_dir_player_warns_when_its_claude_conversation_cannot_be_recorded(self):
        self.env['TEST_SET_OPTION_FAIL'] = '@session-x-orchestra-claude-session'
        x = self.dir_spawn(self.notes_dir(), '--agent', 'claude')
        self.assertNotIn('--session-id', self.calls()[-1]['args']); self.assertIn('cannot be resumed', x.stderr)

    # --- names are labels, tags are identity --------------------------------------------
    def test_sanitize_and_label_table_pinned_with_kirby(self):
        for raw, out in SANITIZE: self.assertEqual(self.lib('sanitize "$1"', raw), out, raw)
        for repo, kind, branch, label in LABELS:
            self.assertEqual(self.lib('session_label "$1" "$2" "$3"', repo, kind, branch), label, (repo, kind, branch))
            self.assertLessEqual(len(label), 200)
    def test_collision_suffix_and_foreign_session_untouched(self):
        self.env['TEST_PANE_ALIVE'] = '1'
        self.foreign(self.session)                                       # a stranger already wears the label
        x = self.spawn('--agent', 'codex'); c = self.calls()[-1]
        self.assertEqual(c['env']['ORCHESTRA_SESSION'], self.session+'-2'); self.assertRegex(x.stdout, r'(?m)^started +repo-feature-test-2$')
        self.assertEqual(self.state()[self.session]['options'], {})      # never tagged, never touched
        self.assertEqual(self.tag('@session-x-orchestra-branch', self.session+'-2'), 'feature/test')
        self.assertIn('running', self.spawn(ok=False).stderr)            # the player exists: found by tags, not by name
        self.spawn('--prompt', 'p', prompt=False, branch='feature/test-2')   # its preferred label is now taken by our own -2: the suffix goes on the label
        self.assertEqual(sorted(self.state()), [self.session, self.session+'-2', self.session+'-2-2'])
        self.assertEqual(self.tag('@session-x-orchestra-branch', self.session+'-2-2'), 'feature/test-2')
        self.clear_log(); self.orch('send.sh', 'feature/test', '--repo', str(self.repo), 'hi')
        self.assertIn('"=%s-2:"' % self.session, self.tmux_log()); self.assertNotIn('"=%s:"' % self.session, self.tmux_log())
        self.clear_log(); self.orch('send.sh', 'feature/test-2', '--repo', str(self.repo), 'hi')
        self.assertIn('"=%s-2-2:"' % self.session, self.tmux_log()); self.assertNotIn('"=%s-2:"' % self.session, self.tmux_log())
        # the stranger's exact name is refused everywhere: it is not one of ours
        for args in (('send.sh', self.session, 'hi'), ('screen.sh', self.session), ('kill.sh', self.session), ('adopt.sh', self.session, '--orchestrator', 'tmux:p')):
            self.clear_log(); x = self.orch(*args, ok=False); self.assertNotEqual(x.returncode, 0, args)
            self.assertNotIn('"=%s:"' % self.session, self.tmux_log(), args); self.assertNotIn('kill-session', self.tmux_log(), args)
        self.assertEqual(sorted(self.state()), [self.session, self.session+'-2', self.session+'-2-2'])
        x = self.report('PROGRESS', 'named', env=self.player_env(ORCHESTRA_SESSION=self.session+'-2'))
        self.assertEqual(self.calls()[-1]['args'][-1], '[player %s-2] PROGRESS: named' % self.session)     # the report carries the session name
    def test_duplicate_name_race_takes_next_suffix(self):
        self.env['TEST_NEW_SESSION_RACE'] = self.session
        self.spawn('--agent', 'codex')
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session+'-2')
        self.assertEqual(self.state()[self.session]['options'], {})      # the winner of the race is left alone
        self.assertEqual(self.tag('@session-x-orchestra-session-type', self.session+'-2'), 'worktree')
        self.assertEqual([c for c in self.tmux_calls() if 'kill-session' in c], [])
    def test_two_lost_races_count_from_the_preferred_label(self):
        self.env['TEST_NEW_SESSION_RACE'] = self.session+','+self.session+'-2'
        self.spawn('--agent', 'codex')
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session+'-3')
        self.assertEqual(sorted(self.state()), [self.session, self.session+'-2', self.session+'-3'])
        self.assertEqual(self.state()[self.session+'-2']['options'], {})
    def test_third_collision(self):
        self.foreign(self.session); self.foreign(self.session+'-2')
        self.spawn('--agent', 'codex')
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session+'-3')
        self.assertEqual(self.tag('@session-x-orchestra-branch', self.session+'-3'), 'feature/test')
        self.assertEqual([n for n in self.state() if self.state()[n]['options']], [self.session+'-3'])
    def test_tags_are_set_before_anything_else_touches_the_session(self):
        self.spawn('--agent', 'codex'); calls = self.tmux_commands()
        i = next(i for i, c in enumerate(calls) if 'new-session' in c and self.session in c)
        self.assertIn('-d', calls[i])
        required = {'@session-launcher', '@session-repo', '@session-worktree', '@session-cwd', '@session-pane',
                    '@session-x-orchestra-session-type', '@session-x-orchestra-branch'}; seen = set()
        for c in calls[i+1:]:
            if not any(t in c for t in ('=%s' % self.session, '=%s:' % self.session)): continue
            if 'set-option' in c and c[-2].startswith('@session-'): seen.add(c[-2]); continue
            self.assertTrue(required <= seen, '%s ran before %s were set' % (c, sorted(required - seen))); break
        self.assertTrue(required <= seen, sorted(required - seen))
        # The version comes last of all the tags spawn.sh writes, and only once the agent is recorded.
        calls = calls[:next(i for i, c in enumerate(calls) if c[0] == 'respawn-pane')]
        sets = [c[-2] for c in calls if c[:1] == ['set-option'] and '-u' not in c and c[-2].startswith('@session-')]
        self.assertEqual(sets.count('@session-version'), 1)
        self.assertLess(sets.index('@session-agent'), sets.index('@session-version'))
        self.assertEqual([k for k in sets[sets.index('@session-version')+1:] if not k.endswith('launching')], [])
    # --- the record: @session-* keys ------------------------------------------------------------
    def options(self, session=None, sock=None): return self.state(sock)[session or self.session]['options']
    def test_spawn_writes_identity_in_one_queue_and_the_version_last(self):
        self.spawn('--agent', 'codex')
        for call in self.tmux_calls():                                         # core keys, then extensions, then the version
            keys = [c[-1] if '-u' in c else c[-2] for c in self.queue(call) if c[0] == 'set-option']
            keys = [k for k in keys if k.startswith('@session-')]
            rank = [2 if k == '@session-version' else 1 if k.startswith('@session-x-') else 0 for k in keys]
            self.assertEqual(rank, sorted(rank), call)
        identity = next(call for call in self.tmux_calls() if '@session-launcher' in call)
        self.assertEqual(sorted(c[-2] for c in self.queue(identity)), sorted(['@session-launcher', '@session-x-orchestra-session-type', '@session-repo',
                         '@session-worktree', '@session-cwd', '@session-x-orchestra-branch', '@session-pane']))
        respawn = next(c for c in self.tmux_commands() if c[0] == 'respawn-pane')
        self.assertEqual(respawn[respawn.index('-t')+1], self.pane())           # by the pane its record names
        self.assertEqual(self.report('PROGRESS', 'recorded').stdout, 'queued for codex:%s\n' % ID)
        self.assertRegex(self.options()['@session-x-orchestra-last-report'], '^PROGRESS '+STAMP+' delivered$')
        self.assertFalse([k for k in self.options() if k.startswith('@orchestra-')])
    def test_values_are_recorded_canonical_or_not_at_all(self):
        real = self.base/'claude-config'; real.mkdir(); (self.base/'cfg-link').symlink_to(real)
        self.env['CLAUDE_CONFIG_DIR'] = str(self.base/'cfg-link')+'/'; self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'codex', '--orchestrator', 'claude:'+ID)
        self.assertEqual(self.options()['@session-x-orchestra-orchestrator-config'], str(real.resolve()))
        self.env['CLAUDE_CONFIG_DIR'] = 'relative/config'
        x = self.orch('adopt.sh', self.session, '--orchestrator', 'claude:'+ID, ok=False)
        self.assertNotEqual(x.returncode, 0); self.assertIn('cannot be recorded in @session-x-orchestra-orchestrator-config', x.stderr)
        # tmux ends a command at an argument ending in ";": such a value still arrives intact; a
        # value the convention cannot carry is unset instead, never written half-right.
        self.foreign('odd')
        self.lib('tag_set "" odd "$KEY_BRANCH" "$1"; tag_set "" odd "$KEY_REPO" relative/path; tag_set "" odd "$KEY_AGENT" "Claude Code"', 'odd;branch\\;')
        self.assertEqual(self.options('odd'), {'@session-x-orchestra-branch': 'odd;branch\\;'})
        self.assertEqual(self.lib('for v in "$@"; do session_value_ok "$KEY_CWD" "$v" && echo "ok $v" || echo "no $v"; done',
                                  '/a/b', '/', '/a/', '/a//b', '/a/./b', '/a/..', 'a', '/a\tb', '/café', '/x\u0085', '/' + 'x'*4096),
                         'ok /a/b\nok /\nno /a/\nno /a//b\nno /a/./b\nno /a/..\nno a\nno /a\tb\nok /café\nno /x\u0085\nno /' + 'x'*4096 + '\n')
    def test_records_from_n10_and_records_this_reader_does_not_understand(self):
        self.env['TEST_PANE_ALIVE'] = '1'
        self.foreign('n10-worktree', self.player_tags(branch='feature/conv', agent='codex'))
        self.foreign('n10-agent-tab', {'@session-agent': 'claude', '@session-launcher': 'n10', '@session-pane': '%8', '@session-cwd': str(self.repo.resolve()),
                                       '@session-x-n10-session-type': 'agent', '@session-x-n10-dir': str(self.repo.resolve()), '@session-version': '1'})
        self.foreign('n10-shell-tab', self.shell_tab_tags())
        self.foreign('next-major', dict(self.player_tags(branch='feature/a'), **{'@session-version': '2'}))
        self.foreign('stranger', self.player_tags(branch='feature/b', launcher='other'))
        self.foreign('bad-agent', self.player_tags(branch='feature/c', agent='Claude Code'))
        self.foreign('relative', dict(self.player_tags(branch='feature/d'), **{'@session-repo': 'repo'}))
        self.foreign('no-version', {k: v for k, v in self.player_tags(branch='feature/e').items() if k != '@session-version'})
        rows = self.sessions('--all'); self.assertEqual([r['session'] for r in rows], ['n10-worktree'])
        r = rows[0]
        self.assertEqual((r['repo'], r['branch'], r['worktree'], r['agent']),
                         (str(self.repo.resolve()), 'feature/conv', str(self.repo.resolve()/'.claude/worktrees/feature-conv'), 'codex'))
        for name in ('n10-agent-tab', 'n10-shell-tab', 'next-major', 'stranger', 'bad-agent', 'relative', 'no-version'):
            self.assertIn('no player session named '+name, self.orch('kill.sh', name, ok=False).stderr)
        self.orch('adopt.sh', 'n10-worktree', '--orchestrator', 'tmux:parent')
        o = self.options('n10-worktree')
        self.assertEqual((o['@session-x-orchestra-orchestrator'], o['@session-launcher'], o['@session-version']), ('tmux:parent', 'n10', '1'))
        self.assertEqual(self.sessions('--all')[0]['orchestrator'], 'tmux:parent')
        self.orch('kill.sh', 'n10-worktree'); self.assertNotIn('n10-worktree', self.state())
    def test_the_version_is_published_only_on_orchestras_own_complete_record(self):
        own = {k: v for k, v in self.player_tags(launcher='orchestra').items() if k != '@session-version'}
        self.foreign('own', own)
        self.foreign('own-incomplete', {k: v for k, v in own.items() if k != '@session-worktree'})
        n10 = {k: v for k, v in self.player_tags().items() if k != '@session-version'}
        self.foreign('n10', dict(n10, **{'@session-x-orchestra-session-type': 'worktree'}))     # even one wearing Orchestra's extension
        self.lib('for s in own own-incomplete n10; do session_publish_version "" "$s"; done')
        self.assertEqual({n: self.options(n).get('@session-version') for n in ('own', 'own-incomplete', 'n10')}, {'own': '1', 'own-incomplete': None, 'n10': None})
    def test_a_resume_with_no_known_harness_registers_the_session_before_it_starts(self):
        # The session is gone (a reboot, say) and no --agent is given: auto. The session is recorded
        # with the harness tried first, so it is listed while it runs and reused after a failed start.
        self.spawn('--agent', 'claude'); self.orch('kill.sh', self.session)
        self.env['TEST_CLAUDE_EXIT'] = '1'; self.spawn('--resume', prompt=False)
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_HARNESS'], 'auto')
        self.assertEqual([(r['session'], r['agent']) for r in self.sessions()], [(self.session, 'claude')])
        self.assertEqual(self.options()['@session-version'], '1')
        del self.env['TEST_CLAUDE_EXIT']; self.spawn('--resume', prompt=False)
        self.assertEqual(sorted(self.state()), [self.session]); self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session)
    def test_a_guessed_agent_never_decides_a_later_resume(self):
        # A Codex player's session vanished. A bare --resume guesses claude; Claude finds no
        # conversation and no Codex rollout is found either, so nothing starts. The next bare
        # --resume must still try Claude then Codex, not settle on the guess.
        self.spawn('--agent', 'codex'); self.orch('kill.sh', self.session)
        self.env['TEST_CLAUDE_NOCONV'] = '1'; self.spawn('--resume', prompt=False)
        o = self.options(); self.assertEqual((o['@session-agent'], o['@session-x-orchestra-agent-provisional'], o['@session-version']), ('claude', '1', '1'))
        self.rollout(str(self.wt.resolve())); n = len(self.calls()); self.spawn('--resume', prompt=False)
        self.assertEqual([c['cli'] for c in self.calls()[n:]], ['claude', 'codex']); self.assertEqual(self.calls()[-1]['args'][:2], ['resume', UUID])
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_HARNESS'], 'auto')
        o = self.options(); self.assertEqual(o['@session-agent'], 'codex'); self.assertNotIn('@session-x-orchestra-agent-provisional', o)
        # A Claude probe that fails for another reason leaves the guess provisional too.
        del self.env['TEST_CLAUDE_NOCONV']; self.orch('kill.sh', self.session); self.env['TEST_CLAUDE_EXIT'] = '1'
        self.spawn('--resume', prompt=False); self.spawn('--resume', prompt=False)
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_HARNESS'], 'auto')
        self.assertEqual(self.options()['@session-x-orchestra-agent-provisional'], '1')
        # An explicit harness is never provisional, even when the launcher never runs to record it.
        del self.env['TEST_CLAUDE_EXIT']; self.kill_pane(); self.env['TEST_RESPAWN_FAIL'] = '1'
        self.spawn('--resume', '--agent', 'codex', prompt=False, ok=False)
        o = self.options(); self.assertEqual(o['@session-agent'], 'codex'); self.assertNotIn('@session-x-orchestra-agent-provisional', o)
    def test_a_failed_spawn_leaves_no_session_behind(self):
        # A config dir or target that cannot be recorded stops the spawn before anything exists.
        mine = self.env['CLAUDE_CONFIG_DIR']
        for config, target in (('relative/config', 'claude:'+ID), (mine, 'tmux:'+'a'*4100)):
            self.env['CLAUDE_CONFIG_DIR'] = config
            x = self.spawn('--agent', 'codex', '--orchestrator', target, ok=False)
            self.assertEqual(x.returncode, 2, x.stderr); self.assertIn('cannot be recorded', x.stderr)
            self.assertNotIn('new-session', self.tmux_log() if (self.base/'tmux-log').exists() else '')
        self.env['CLAUDE_CONFIG_DIR'] = mine
        # A write that fails after the session exists removes it, so a retry gets the same label.
        self.env['TEST_SET_OPTION_FAIL'] = '@session-x-orchestra-launching'
        x = self.spawn('--agent', 'codex', ok=False); self.assertIn('removed', x.stderr)
        self.assertEqual(self.state(), {})
        del self.env['TEST_SET_OPTION_FAIL']; self.spawn('--agent', 'codex')
        self.assertEqual(sorted(self.state()), [self.session])
    def test_a_dir_player_whose_version_was_not_written_still_launches_as_one(self):
        self.env['TEST_SET_OPTION_FAIL'] = '@session-agent'
        d = self.notes_dir(); self.dir_spawn(d, '--agent', 'claude')
        self.assertNotIn('@session-version', self.options('notes-dir'))
        args = self.calls()[-1]['args']; self.assertIn('--session-id', args)
        self.assertEqual(args[args.index('--session-id')+1], self.options('notes-dir')['@session-x-orchestra-claude-session'])
    def test_resume_respawns_the_recorded_pane_only_while_it_belongs_to_the_session(self):
        self.spawn('--agent', 'codex'); self.foreign('elsewhere'); own = self.pane()
        self.set_tag('@session-pane', self.pane('elsewhere')); self.kill_pane()
        self.spawn('--resume', prompt=False)
        respawn = [c for c in self.tmux_commands() if c[0] == 'respawn-pane'][-1]
        self.assertEqual(respawn[respawn.index('-t')+1], '=%s:' % self.session)       # another session's pane: never touched
        self.set_tag('@session-pane', own); self.kill_pane(); self.spawn('--resume', prompt=False)
        respawn = [c for c in self.tmux_commands() if c[0] == 'respawn-pane'][-1]
        self.assertEqual(respawn[respawn.index('-t')+1], own)
    def test_status_keys_are_withdrawn_before_an_agent_is_replaced(self):
        self.spawn('--agent', 'codex')
        for k, v in (('@session-status', 'blocked'), ('@session-status-kind', 'question'), ('@session-status-at', '2026-01-01T00:00:00Z')): self.set_tag(k, v)
        self.kill_pane(); self.spawn('--resume', prompt=False)
        self.assertFalse([k for k in self.options() if k.startswith('@session-status')])
    def test_resolver_uses_tags_not_names(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        self.rename(self.session, 'some-label')                          # a label is never parsed
        self.foreign(self.session)                                       # and a stranger now wears the old one
        self.clear_log(); self.orch('send.sh', 'feature/test', '--repo', str(self.repo), 'hello')
        self.assertIn('"=some-label:"', self.tmux_log()); self.assertNotIn('"=%s:"' % self.session, self.tmux_log())
        self.orch('send.sh', 'some-label', 'hello')                      # an exact player name needs no repo
        self.assertIn('running', self.spawn(ok=False).stderr)
        self.kill_pane('some-label'); self.spawn('--resume', '--agent', 'claude', prompt=False)     # --resume resolves (repo, branch) too
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], 'some-label'); self.assertEqual(sorted(self.state()), [self.session, 'some-label'])
        rows = self.sessions('--repo', str(self.repo)); self.assertEqual([(r['session'], r['name'], r['branch']) for r in rows], [('some-label', 'some-label', 'feature/test')])
        # two sessions with one identity (should not happen): the oldest wins, the other is reported, nothing is killed
        self.foreign('twin', self.player_tags(launcher='orchestra'))
        x = self.orch('screen.sh', 'feature/test', '--repo', str(self.repo)); self.assertIn('"=some-label:"', self.tmux_log()); self.assertIn('twin', x.stderr)
        s = self.state(); s['twin']['created'] = 0; self.set_state(s); self.clear_log()
        self.orch('screen.sh', 'feature/test', '--repo', str(self.repo)); self.assertIn('"=twin:"', self.tmux_log())
        self.assertEqual(sorted(self.state()), [self.session, 'some-label', 'twin'])
    def test_worktree_player_follows_its_checkout_across_a_branch_switch(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        self.run_cmd(['git', 'switch', '-q', '-c', 'feature/renamed'], cwd=self.wt)
        rows = self.sessions('--repo', str(self.repo))
        self.assertEqual([(r['session'], r['branch'], r['worktree']) for r in rows], [(self.session, 'feature/test', str(self.wt.resolve()))])
        self.clear_log(); self.orch('send.sh', 'feature/renamed', '--repo', str(self.repo), 'hi'); self.assertIn('"=%s:"' % self.session, self.tmux_log())
        x = self.orch('send.sh', 'feature/test', '--repo', str(self.repo), 'hi', ok=False); self.assertNotEqual(x.returncode, 0)   # no checkout is on it now
        x = self.spawn(ok=False)                                               # spawn finds it by its checkout, not by its branch tag
        self.assertIn('running', x.stderr); self.assertIn('which is now on feature/renamed', x.stderr)
        self.kill_pane(); self.spawn('--resume', '--agent', 'claude', prompt=False)   # and resumes it in the switched checkout
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session); self.assertEqual(sorted(self.state()), [self.session])
        s = self.state(); s[self.session]['options']['@session-x-orchestra-launching'] = '1'; self.set_state(s)   # a placeholder never starts a fresh task in a switched checkout
        x = self.spawn(ok=False); self.assertIn('does not match requested branch', x.stderr); self.assertIn('is on feature/renamed', x.stderr)
        self.orch('kill.sh', self.session); self.spawn('--resume', '--agent', 'claude', prompt=False)   # nor does a vanished session block resuming it
        self.assertEqual(self.tag('@session-worktree'), str(self.wt.resolve()))
        # another worktree on the original branch never claims the session
        self.run_cmd(['git', 'worktree', 'add', '-q', str(self.base/'elsewhere'), 'feature/test'], cwd=self.repo)
        x = self.orch('send.sh', 'feature/test', '--repo', str(self.repo), 'hi', ok=False); self.assertNotEqual(x.returncode, 0)
    def test_resolve_by_branch_across_repos(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        repo2 = self.base/'other/repo'; self.git_init(repo2); self.spawn('--agent', 'codex', repo=repo2)
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session+'-2')      # same basename, different repo
        x = self.orch('send.sh', 'feature/test', 'hi', cwd=self.base, ok=False)              # outside any repo: ambiguous
        self.assertNotEqual(x.returncode, 0); self.assertIn(self.session, x.stderr); self.assertIn(self.session+'-2', x.stderr); self.assertNotIn('paste-buffer', self.tmux_log())
        self.clear_log(); self.orch('send.sh', 'feature/test', '--repo', str(repo2), 'hi', cwd=self.base); self.assertIn('"=%s-2:"' % self.session, self.tmux_log())
        self.clear_log(); self.orch('send.sh', 'feature/test', 'hi', cwd=self.wt); self.assertIn('"=%s:"' % self.session, self.tmux_log())   # cwd inside a worktree selects its repo
        self.clear_log(); self.orch('send.sh', self.session+'-2', 'hi', cwd=self.base); self.assertIn('"=%s-2:"' % self.session, self.tmux_log())
        self.orch('kill.sh', 'feature/test', '--repo', str(repo2)); self.assertEqual(sorted(self.state()), [self.session])
        self.clear_log(); self.orch('send.sh', 'feature/test', 'hi', cwd=self.base); self.assertIn('"=%s:"' % self.session, self.tmux_log())   # unique again
        x = self.orch('send.sh', 'feature/test', '--repo', str(repo2), 'hi', ok=False); self.assertNotEqual(x.returncode, 0)          # scoped: not in that repo
    def test_kill_and_adopt_refuse_untagged_sessions(self):
        self.env['TEST_PANE_ALIVE'] = '1'
        self.foreign(self.session)
        half = dict(self.player_tags(launcher='orchestra')); del half['@session-version']; self.foreign('half-tagged', half)   # never registered
        self.foreign('repo-shell', self.shell_tab_tags())                                                                    # n10's shell tab, not a player
        # A session Orchestra or n10 tagged before the convention: its @orchestra-* tags mean nothing now.
        self.foreign('legacy-only', {'@orchestra-spawner': 'orchestra', '@orchestra-repo': str(self.repo.resolve()), '@orchestra-session-type': 'worktree',
                                     '@orchestra-branch': 'feature/test', '@orchestra-worktree-path': str(self.wt.resolve()), '@orchestra-agent': 'codex'})
        norepo = self.player_tags(launcher='orchestra'); del norepo['@session-repo']; self.foreign('no-repo-tag', norepo)
        nopath = self.player_tags(launcher='orchestra'); del nopath['@session-worktree']; self.foreign('no-checkout-tag', nopath)
        self.assertEqual(self.sessions('--all'), [])
        before = self.state()
        for name in (self.session, 'half-tagged', 'repo-shell', 'legacy-only', 'no-repo-tag', 'no-checkout-tag'):
            self.assertNotEqual(self.orch('kill.sh', name, ok=False).returncode, 0)
            self.assertNotEqual(self.orch('adopt.sh', name, '--orchestrator', 'tmux:p', ok=False).returncode, 0)
        self.assertNotIn('kill-session', self.tmux_log()); self.assertNotIn('send-keys', self.tmux_log()); self.assertEqual(self.state(), before)
    def test_kill_preserves_worktree_files_and_branch_until_explicit_cleanup(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        artifact = self.wt/'dev-server-output.txt'; artifact.write_text('keep this output')
        head = self.run_cmd(['git', 'rev-parse', 'HEAD'], cwd=self.wt).stdout
        self.orch('kill.sh', self.session)
        self.assertNotIn(self.session, self.state())
        self.assertEqual(artifact.read_text(), 'keep this output')
        self.assertEqual(self.run_cmd(['git', 'rev-parse', 'feature/test']).stdout, head)
        self.assertIn(str(self.wt), self.run_cmd(['git', 'worktree', 'list', '--porcelain']).stdout)

    def test_kill_reports_a_refused_kill(self):
        self.spawn('--agent', 'codex'); self.env['TEST_KILL_FAIL'] = '1'
        x = self.orch('kill.sh', self.session, ok=False); self.assertNotEqual(x.returncode, 0); self.assertIn('could not kill', x.stderr); self.assertNotIn('killed', x.stdout)
        self.assertIn(self.session, self.state())
    def test_sessions_scoped_by_repo_tag(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        repo2 = self.base/'other/repo'; self.git_init(repo2); self.spawn('--agent', 'codex', repo=repo2)
        self.foreign('stray'); self.foreign('repo-shell', self.shell_tab_tags())
        self.foreign('tab-made-elsewhere', self.player_tags(branch='feature/other'))
        norepo = self.player_tags(branch='feature/norepo'); del norepo['@session-repo']; self.foreign('no-repo-tag', norepo)   # not ours without a repo tag
        names = lambda rows: sorted(r['session'] for r in rows)
        self.assertEqual(names(self.sessions('--repo', str(self.repo))), sorted([self.session, 'tab-made-elsewhere']))
        self.assertEqual(names(self.sessions()), sorted([self.session, 'tab-made-elsewhere']))                    # cwd's repo
        self.assertEqual(names(self.sessions('--repo', str(repo2))), [self.session+'-2'])
        self.assertEqual(names(self.sessions('--all')), sorted([self.session, self.session+'-2', 'tab-made-elsewhere']))
        self.assertEqual(names(json.loads(self.orch('sessions.sh', '--json', cwd=self.base).stdout)), sorted([self.session, self.session+'-2', 'tab-made-elsewhere']))   # outside a repo: everything
        text = self.orch('sessions.sh', '--all').stdout.splitlines()
        self.assertEqual(text[0].split(), ['STATE', 'QUIET', 'REPO', 'SESSION', 'BRANCH', 'AGENT', 'ORCHESTRATOR', 'LAST-REPORT', 'TITLE'])
        self.assertTrue(any(l.split()[2:5] == [str(repo2.resolve())[:40], self.session+'-2', 'feature/test'] for l in text[1:]), text)   # REPO is the tag value (cut to 40; JSON has it whole)
        self.assertNotIn('stray', '\n'.join(text)); self.assertNotIn('repo-shell', '\n'.join(text)); self.assertNotIn('no-repo-tag', '\n'.join(text))
        self.env['TEST_PANE_COMMAND'] = 'we"ird\\cmd'
        rows = self.sessions('--all'); self.assertEqual(rows[0]['cmd'], 'we"ird\\cmd'); self.assertEqual(rows[0]['state'], 'idle')
        text = self.orch('sessions.sh', '--repo', str(self.repo)).stdout.splitlines()
        self.assertEqual(text[0].split(), ['STATE', 'QUIET', 'SESSION', 'BRANCH', 'AGENT', 'ORCHESTRATOR', 'LAST-REPORT', 'TITLE'])
        self.assertTrue(any(l.split()[2:4] == ['tab-made-elsewhere', 'feature/other'] for l in text[1:]), text)
    def test_sessions_sample_keyed_by_machine_and_shows_peer_labels(self):
        # B8: --sample's before[] snapshot used to be taken once, for the starting (local)
        # machine only, keyed by bare session name. A remote row then always compared its
        # (never-populated) baseline as different from the after-shot and read "busy"
        # unconditionally — wrong regardless of whether anything actually changed there. Keying
        # by machine+name and taking the baseline per machine fixes that; the mock's capture-pane
        # never produces different output (see TMUX_MOCK), so a correct baseline reads "idle" on
        # every machine, the way nothing having changed actually should.
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        self.stub('beam', BEAM_MOCK); self.env['TEST_BEAM_PEERS'] = PEER+':workbox'
        rows = self.sessions('--all', '--sample', '1')
        self.assertEqual(sorted(r['machine'] for r in rows), ['local', 'workbox'])
        self.assertEqual({r['machine']: r['state'] for r in rows}, {'local': 'idle', 'workbox': 'idle'})
        text = self.orch('sessions.sh', '--all').stdout.splitlines()
        self.assertTrue(any('workbox' in l for l in text[1:]), text)                # the label
        self.assertFalse(any(PEER in l for l in text[1:]), text)                    # never the raw peerId

    def test_peer_labels_with_braces_quotes_and_backslashes_do_not_desync_the_scan(self):
        # A peer's label is chosen on that peer's machine. Scanning `beam peers --json` for the
        # next "{...}" ended the first peer's object at the "}" inside its label and resumed from
        # there, so that peer lost its label and every peer after it was garbled or dropped —
        # rows missing from sessions.sh --all for machines that are registered and reachable.
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        self.stub('beam', BEAM_MOCK)
        hostile = 'work}box "one" \\ two{'
        self.env['TEST_BEAM_PEERS_JSON'] = json.dumps(
            [{'peerId': PEER, 'label': hostile, 'alias': None, 'state': 'connected', 'queue': {'outbound': 0, 'inbound': 0, 'refused': 0}},
             {'peerId': 'fedcba0987654321fedcba0987654321', 'label': 'peers', 'alias': 'plain', 'state': 'offline', 'queue': {'outbound': 1, 'inbound': 0, 'refused': 0}}])
        rows = self.sessions('--all')
        self.assertEqual(sorted(r['machine'] for r in rows), sorted(['local', hostile, 'plain']), rows)
        self.assertFalse(any(PEER == r['machine'] for r in rows), rows)     # the label, not the raw peerId
    def test_json_array_objects_rejects_a_malformed_array(self):
        # No half-parsed answer: a truncated document yields no peers rather than a plausible
        # prefix of them, so a machine is never silently left out of a listing that looks complete.
        for bad in ('[{"peerId":"x"', '[{"peerId":"unterminated}', 'not json at all', '[}]'):
            x = self.run_cmd(['bash', '-c', '. "$0"; json_array_objects "$1" || exit 1; printf "%s\\n" "${#JSON_OBJECTS[@]}"',
                               str(ROOT/'player/scripts/_routing.sh'), bad], ok=False)
            self.assertNotEqual(x.returncode, 0, bad)
        x = self.run_cmd(['bash', '-c', '. "$0"; json_array_objects "$1"; printf "%s\\n" "${#JSON_OBJECTS[@]}"',
                           str(ROOT/'player/scripts/_routing.sh'), '[{"a":{"b":"}"}},{"c":"\\""}]'])
        self.assertEqual(x.stdout.strip(), '2')          # nested objects and escaped quotes, both counted once
        # `beam peers --json` wraps the array in {"peers": …}: unwrapped by field, scanning stops at
        # the array's own "]", and a "peers" that is not an array (or never closes) yields nothing.
        wrapped = '{\n  "peers": [\n    {"peerId": "a", "label": "peers", "tags": ["]"]},\n    {"peerId": "b"}\n  ]\n}'
        x = self.run_cmd(['bash', '-c', '. "$0"; json_array_objects "$1" peers; printf "%s\n" "${#JSON_OBJECTS[@]}"',
                           str(ROOT/'player/scripts/_routing.sh'), wrapped])
        self.assertEqual(x.stdout.strip(), '2')
        for bad in ('{"peers": {}}', '{"peers": [{"peerId":"x"}', '{"other": []}'):
            x = self.run_cmd(['bash', '-c', '. "$0"; json_array_objects "$1" peers', str(ROOT/'player/scripts/_routing.sh'), bad], ok=False)
            self.assertNotEqual(x.returncode, 0, bad)

    # --- resume ----------------------------------------------------------------------
    def test_resume_default_restart_note_only_no_replay_no_overrides(self):
        self.spawn('--agent', 'claude', '--model', 'fable'); self.kill_pane()
        self.spawn('--resume', prompt=False); c = self.calls()[-1]
        self.assertEqual(c['cli'], 'claude'); self.assertEqual(c['args'][0], '--continue'); self.assertNotIn('--model', c['args']); self.assertNotIn('--effort', c['args'])
        self.assertTrue(c['args'][-1].startswith(INV+' '+RESTART), c['args'][-1]); self.assertTrue(c['args'][-1].endswith('finished work.'))
        self.assertNotIn('END-OF-TASK', c['args'][-1]); self.assertNotIn('reporting target', c['args'][-1])
        self.assertEqual(c['env']['ORCHESTRA_MODE'], 'resume'); self.assertEqual(self.buffers(), {})
    def test_resume_new_assignment_and_explicit_overrides(self):
        self.spawn('--agent', 'claude'); self.kill_pane()
        self.spawn('--resume', '--prompt', 'Next: the follow-up', '--model', 'opus', '--effort', 'max', prompt=False); c = self.calls()[-1]
        self.assertEqual(c['args'][:5], ['--continue', '--model', 'opus', '--effort', 'max'])
        self.assertTrue(c['args'][-1].startswith(INV+' '+RESTART)); self.assertTrue(c['args'][-1].endswith('\n\nNext: the follow-up')); self.assertNotIn('END-OF-TASK', c['args'][-1])
    def test_resume_codex_by_tag_uses_worktree_conversation(self):
        self.spawn('--agent', 'codex'); self.kill_pane()
        self.rollout('/elsewhere', uuid='0199a000-1111-7000-8000-000000000099', stamp='2026-09-13T12-00-00'); self.rollout(str(self.wt.resolve()))
        self.spawn('--resume', prompt=False); c = self.calls()[-1]
        self.assertEqual(c['cli'], 'codex'); self.assertEqual(c['args'][:2], ['resume', UUID]); self.assertTrue(c['args'][-1].startswith('$player '+RESTART)); self.assertNotIn('-m', c['args'])
        self.spawn('--resume', '--model', 'gpt-5.6-sol', '--effort', 'high', prompt=False)
        self.assertEqual(self.calls()[-1]['args'][:6], ['resume', '-m', 'gpt-5.6-sol', '-c', 'model_reasoning_effort="high"', UUID])
    def test_resume_codex_without_conversation_refuses(self):
        self.spawn('--agent', 'codex'); self.kill_pane(); n = len(self.calls())
        self.spawn('--resume', prompt=False)
        self.assertEqual(len(self.calls()), n); self.assertEqual(self.state()[self.session]['dead'], 1); self.assertEqual(self.state()[self.session]['status'], 1)
    def test_resume_auto_chain(self):
        self.spawn('--agent', 'claude'); self.kill_pane(); self.set_tag('@session-agent', 'custom')
        self.rollout(str(self.wt.resolve()))
        self.env['TEST_CLAUDE_NOCONV'] = '1'; self.spawn('--resume', prompt=False)
        seq = [c['cli'] for c in self.calls()[1:]]; self.assertEqual(seq, ['claude', 'codex'])
        self.assertEqual(self.calls()[-1]['args'][:2], ['resume', UUID]); self.assertEqual(self.tag('@session-agent'), 'codex')   # the launcher records what started
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_HARNESS'], 'auto')
        del self.env['TEST_CLAUDE_NOCONV']
        for exit_code in ('1', '0'):     # other failures and successes never fall through to Codex
            self.set_tag('@session-agent', 'custom'); self.kill_pane()
            n = len(self.calls()); self.env['TEST_CLAUDE_EXIT'] = exit_code; self.spawn('--resume', prompt=False)
            self.assertEqual([c['cli'] for c in self.calls()[n:]], ['claude'])
        self.assertEqual(self.tag('@session-agent'), 'claude')
    def test_resume_with_no_conversation_names_the_config_dir(self):
        self.spawn('--agent', 'claude'); self.kill_pane(); self.set_tag('@session-agent', 'custom')
        self.env['TEST_CLAUDE_NOCONV'] = '1'
        for named in (str(self.base/'claude-config'), 'the default ~/.claude (CLAUDE_CONFIG_DIR unset)'):
            for agent in ((), ('--agent', 'claude')):      # auto mode, then the explicit harness
                x = self.spawn('--resume', *agent, prompt=False, ok=False); self.kill_pane()
                last = x.stderr.strip().splitlines()[-1]
                self.assertIn('no Claude conversation for %s exists under the active config dir, %s' % (self.wt, named), last, agent)
                self.assertIn('spawned with', last, agent); self.assertNotIn('no Codex conversation is recorded', x.stderr)
            self.env.pop('CLAUDE_CONFIG_DIR', None)
    def test_resume_explicit_agent_wins_and_session_gone(self):
        self.spawn('--agent', 'codex'); self.orch('kill.sh', self.session, '--repo', str(self.repo))
        self.spawn('--resume', '--agent', 'claude', prompt=False); c = self.calls()[-1]
        self.assertEqual(c['cli'], 'claude'); self.assertEqual(c['args'][0], '--continue'); self.assertIn(self.session, self.state())
        self.assertEqual(self.tag('@session-launcher'), 'orchestra'); self.assertEqual(self.tag('@session-x-orchestra-branch'), 'feature/test'); self.assertEqual(self.tag('@session-x-orchestra-session-type'), 'worktree')
        # gone again, and a stranger has taken the label meanwhile: the recreated session gets the next one
        self.orch('kill.sh', 'feature/test', '--repo', str(self.repo)); self.foreign(self.session)
        self.spawn('--resume', '--agent', 'claude', prompt=False)
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SESSION'], self.session+'-2'); self.assertEqual(self.tag('@session-x-orchestra-branch', self.session+'-2'), 'feature/test')
        self.assertEqual(self.state()[self.session]['options'], {})

    def test_resume_keeps_n10_identity_tags(self):
        self.spawn('--agent', 'codex'); self.orch('kill.sh', self.session)             # leaves the worktree behind
        n10 = self.player_tags(launcher='n10'); self.foreign('label-chosen-elsewhere', n10); self.kill_pane('label-chosen-elsewhere')
        self.spawn('--resume', '--agent', 'claude', prompt=False); c = self.calls()[-1]
        self.assertEqual(c['cli'], 'claude'); self.assertEqual(c['env']['ORCHESTRA_SESSION'], 'label-chosen-elsewhere')
        opts = self.state()['label-chosen-elsewhere']['options']
        self.assertEqual({k: opts.get(k) for k in n10 if k != '@session-agent'}, {k: v for k, v in n10.items() if k != '@session-agent'})   # creator-only tags untouched
        self.assertEqual(opts['@session-agent'], 'claude'); self.assertEqual(opts['@session-x-orchestra-orchestrator'], 'codex:'+ID)
        self.assertEqual(sorted(self.state()), ['label-chosen-elsewhere'])
    def assert_reads_pass_utf8(self):
        reads = [c for c in self.tmux_calls() if any(k in c for k in ('display-message', 'show-options', 'list-sessions', 'list-panes'))]
        self.assertTrue(reads); self.assertEqual([c for c in reads if c[0] != '-u'], [])

    # --- reporting -------------------------------------------------------------------
    def assert_delivery_failed(self, result, destination, reason, kind, text, session=None):
        self.assertEqual(result.returncode, 1)
        self.assertIn('report.sh: delivery failed\nTarget: '+destination+'\nReason: '+reason, result.stderr)
        self.assertTrue(result.stderr.endswith('Report: [player %s] %s: %s\n' % (session or self.session, kind, text)), result.stderr)
        self.assertNotIn('queued for', result.stdout); self.assertNotIn('sent to', result.stdout); self.assertNotIn('stored for', result.stdout)
    def test_report_codex_records_success_and_prints_failure(self):
        self.spawn('--agent', 'codex')
        x = self.report('PROGRESS', 'one\ntwo $(touch BAD)')
        self.assertEqual(self.calls()[-1]['args'][:5], ['queue', '--thread', ID, '--message', '[player repo-feature-test] PROGRESS: one\ntwo $(touch BAD)']); self.assertIn('queued for', x.stdout)
        self.assertRegex(self.last_report(), '^PROGRESS '+STAMP+' delivered$')
        before = self.state(); n = len(self.calls())
        self.env['TEST_CLI_EXIT'] = '1'; text = 'two\nlines\twith tab'
        x = self.report('BLOCKED', text, ok=False)
        self.assert_delivery_failed(x, 'codex:'+ID, 'Codex queue refused', 'BLOCKED', text)
        self.assertEqual(self.state(), before)                       # no session writes after failed delivery
        self.assertEqual(len(self.calls()), n+1)                    # one attempt, no retry
        self.assert_no_state_files()
    def test_failed_report_preserves_complete_large_message(self):
        self.spawn('--agent', 'codex'); self.env['TEST_CLI_EXIT'] = '1'
        text = 'Résumé\n'+('h'*20000)+'\t100% $(touch BAD)\nEND\n'
        before = self.state(); x = self.report('DONE', text, ok=False)
        self.assert_delivery_failed(x, 'codex:'+ID, 'Codex queue refused', 'DONE', text)
        self.assertEqual(self.state(), before); self.assertFalse((self.wt/'BAD').exists())
    def test_report_outside_player_pane_prints_failure(self):
        self.spawn('--agent', 'codex'); n = len(self.calls()); before = self.state()
        x = self.report('DONE', 'lost text', env=self.env, ok=False)      # no ORCHESTRA_SESSION / ORCHESTRA_SOCKET
        self.assert_delivery_failed(x, '<unknown>', 'neither ORCHESTRA_SESSION nor TMUX', 'DONE', 'lost text', session=self.wt.name)
        self.assertEqual(len(self.calls()), n); self.assertEqual(self.state(), before)
    def test_invalid_report_target_is_printed_intact(self):
        self.spawn('--agent', 'codex')
        self.run_cmd(['tmux', 'set-option', '-t', '='+self.session+':', '@session-x-orchestra-orchestrator', 'codex:not-a-thread'])
        before = self.state(); n = len(self.calls())
        x = self.report('QUESTION', 'where next?', ok=False)
        self.assert_delivery_failed(x, 'codex:not-a-thread', 'invalid orchestrator target', 'QUESTION', 'where next?')
        self.assertEqual(len(self.calls()), n); self.assertEqual(self.state(), before)
    def test_report_with_missing_session_prints_failure(self):
        self.spawn('--agent', 'codex'); self.run_cmd(['tmux', 'kill-session', '-t', '='+self.session])
        x = self.report('DONE', 'session gone', ok=False)
        self.assert_delivery_failed(x, '<unknown>', 'orchestrator target is unset or unreachable', 'DONE', 'session gone')
    def test_tmux_load_and_submit_failures_print_report(self):
        self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        before = self.state()
        for flag, reason in [('TEST_LOAD_FAIL', 'tmux could not load'), ('TEST_SEND_KEYS_FAIL', 'tmux could not submit')]:
            with self.subTest(flag=flag):
                self.clear_log(); self.env[flag] = '1'
                x = self.report('DONE', 'one\ntwo', ok=False)
                self.assert_delivery_failed(x, 'tmux:parent', reason, 'DONE', 'one\ntwo')
                self.assertEqual(self.state(), before); self.assertEqual(self.buffers(), {})
                if flag == 'TEST_SEND_KEYS_FAIL':
                    self.assertIn('the paste succeeded, inspect before retrying', x.stderr)
                    self.assertEqual(sum('paste-buffer' in c for c in self.tmux_calls()), 1)
                    self.assertEqual(sum('send-keys' in c for c in self.tmux_calls()), 1)
                else:
                    self.assertNotIn('paste-buffer', self.tmux_log())
                del self.env[flag]
    def test_report_from_pane_without_orchestra_env_uses_tmux(self):
        self.env['TMUX'] = '/tmp/custom-socket,7,0'          # the session lives on that server, as $TMUX says
        self.spawn('--agent', 'codex'); self.rename(self.session, 'label-chosen-elsewhere', sock='/tmp/custom-socket')     # a pane Kirby started, under whatever label Kirby chose
        inside = dict(self.env, TEST_TMUX_SESSION='label-chosen-elsewhere')
        self.assertEqual(self.report('--orchestrator', env=inside).stdout.strip(), 'codex:'+ID)
        self.clear_log(); x = self.report('PROGRESS', 'derived', env=inside); self.assertIn('queued for', x.stdout)
        self.assertEqual(self.calls()[-1]['args'][:5], ['queue', '--thread', ID, '--message', '[player label-chosen-elsewhere] PROGRESS: derived'])
        self.assertRegex(self.tag('@session-x-orchestra-last-report', 'label-chosen-elsewhere', sock='/tmp/custom-socket'), '^PROGRESS '+STAMP+' delivered$'); self.assertIn('"-S", "/tmp/custom-socket", "set-option"', self.tmux_log())
        self.assertIn('["-u", "-S", "/tmp/custom-socket", "display-message"', self.tmux_log())        # the session lookup goes through tmux_on too
        x = self.report('DONE', 'derived fail', env=dict(inside, TEST_CLI_EXIT='1'), ok=False)
        self.assert_delivery_failed(x, 'codex:'+ID, 'Codex queue refused', 'DONE', 'derived fail', session='label-chosen-elsewhere')
    def test_help_text_is_the_whole_header_comment(self):
        # Usage output is exactly the run of "#" lines from line 2 to the first non-comment line: no
        # code line printed, no header line dropped.
        def header(script):
            lines = Path(self.script(script)).read_text().splitlines()[1:]
            out = []
            for l in lines:
                if not l.startswith('#'): break
                out.append(l)
            return '\n'.join(out) + '\n'
        for s, args in (('spawn.sh', ['--help']), ('sessions.sh', ['--help'])):
            x = self.orch(s, *args); self.assertIn('Usage: '+s, x.stdout); self.assertEqual(x.stdout, header(s), s)
        for s in ('report.sh', 'kill.sh', 'adopt.sh', 'send.sh', 'screen.sh'):
            x = self.run_cmd(['bash', self.script(s)], ok=False); self.assertEqual(x.returncode, 2, s); self.assertIn('Usage: '+s, x.stderr)
            self.assertEqual(x.stderr, header(s), s)
    def test_orchestrator_query_is_read_only(self):
        self.spawn('--agent', 'codex')
        self.assertEqual(self.report('--orchestrator').stdout.strip(), 'codex:'+ID)
        x = self.report('--orchestrator', 'tmux:elsewhere', ok=False); self.assertEqual(x.returncode, 2)
        x = self.report('--orchestrator', 'tmux:elsewhere', '--socket', '/tmp/x', ok=False); self.assertEqual(x.returncode, 2)
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'codex:'+ID)
        x = self.report('--orchestrator', env=self.env, ok=False); self.assertNotEqual(x.returncode, 0)
    def test_tmux_delivery_uses_socket_and_sets_last_report(self):
        self.env['TMUX'] = '/tmp/custom-socket,1,1'
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent')
        self.assertEqual(self.calls()[-1]['env']['ORCHESTRA_SOCKET'], '/tmp/custom-socket')
        self.foreign('parent', sock='/tmp/custom-socket'); self.clear_log()
        x = self.report('PROGRESS', 'tmux delivery', env=self.player_env(ORCHESTRA_SOCKET='/tmp/custom-socket')); log = self.tmux_log()
        self.assertIn('"-S", "/tmp/custom-socket", "load-buffer"', log); self.assertIn('paste-buffer', log); self.assertIn('"=parent:"', log)
        self.assertEqual((self.base/'buffer').read_text(), '[player repo-feature-test] PROGRESS: tmux delivery')
        self.assertEqual(x.stdout, 'sent to parent (paste)\n')
        self.assertRegex(self.last_report(sock='/tmp/custom-socket'), '^PROGRESS '+STAMP+' paste$')
        self.run_cmd(['tmux', '-S', '/tmp/custom-socket', 'kill-session', '-t', '=parent'])
        x = self.report('DONE', 'gone', env=self.player_env(ORCHESTRA_SOCKET='/tmp/custom-socket'), ok=False)
        self.assert_delivery_failed(x, 'tmux:parent', 'orchestrator session parent is gone', 'DONE', 'gone')
    # A Claude Code orchestrator: the report goes to its inbox socket, found through the session
    # registry file Claude writes for its pid, and never touches the pane.
    def fake_claude(self, register=True, listen=True, proc_start=None, config=None, session=UUID, pid_domain=None, register_pid=None):
        import socket, threading
        proc = subprocess.Popen(['bash', '-c', 'exec -a claude sleep 30'], stdin=subprocess.DEVNULL)
        self.addCleanup(proc.wait); self.addCleanup(proc.kill)       # cleanups run last-in first-out
        for _ in range(100):                               # until exec has replaced bash
            if (Path('/proc/%d/cmdline' % proc.pid).read_bytes().split(b'\0')[0] == b'claude'): break
            import time; time.sleep(0.02)
        sock_path = str(self.base/('inbox-%d.sock' % proc.pid)); received = []
        srv = socket.socket(socket.AF_UNIX); srv.bind(sock_path)
        if listen:
            srv.listen(1)
            def serve():
                conn, _ = srv.accept(); data = b''
                while True:
                    chunk = conn.recv(65536)
                    if not chunk: break
                    data += chunk
                received.append(data); conn.close()
            t = threading.Thread(target=serve, daemon=True); t.start(); self.addCleanup(t.join, 5)
        else:
            srv.close()                                    # the file stays, nothing listens: connection refused
        self.addCleanup(lambda: srv.close())
        if register:
            stat = Path('/proc/%d/stat' % proc.pid).read_text()
            start = stat.rsplit(') ', 1)[1].split()[19]
            d = Path(config or self.base/'claude-config')/'sessions'; d.mkdir(parents=True, exist_ok=True)
            pid = register_pid or proc.pid
            entry = {'pid': pid, 'sessionId': session, 'procStart': proc_start or start, 'kind': 'interactive', 'entrypoint': 'cli',
                     'pidDomain': pid_domain or self.pid_domain(), 'messagingSocketPath': sock_path, 'status': 'idle'}
            if proc_start is False: del entry['procStart']                  # no start time recorded: liveness is all that is left
            (d/('%d.json' % pid)).write_text(json.dumps(entry))
        self.env.update(TEST_PANE_COMMAND='claude', TEST_PANE_PID=str(proc.pid)); self.fake_claude_pid = proc.pid
        return received
    # Claude's pidDomain for a process in this pid namespace on this machine (as 2.1.280 writes it).
    def pid_domain(self): return 'linux:%s:%s' % (Path('/etc/machine-id').read_text().strip(), os.readlink('/proc/self/ns/pid'))
    def wait_for(self, received):
        import time
        for _ in range(100):
            if received: break
            time.sleep(0.05)
    def test_claude_orchestrator_gets_the_report_on_its_inbox_socket(self):
        self.spawn('--agent', 'codex', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        received = self.fake_claude(); self.clear_log()
        text = 'one\ntwo "quoted" \\ back\ttab $(touch BAD) \u00e9'
        x = self.report('DONE', text)
        self.assertEqual(x.stdout, 'sent to parent (inbox)\n')
        self.assertRegex(self.last_report(), '^DONE '+STAMP+' inbox$')
        for _ in range(100):
            if received: break
            import time; time.sleep(0.05)
        self.assertEqual(len(received), 1); self.assertTrue(received[0].endswith(b'\n')); self.assertEqual(received[0].count(b'\n'), 1)
        self.assertEqual(json.loads(received[0]), {'type': 'user', 'message': {'role': 'user', 'content': '[player %s] DONE: %s' % (self.session, text)}})
        for cmd in ('load-buffer', 'paste-buffer', 'send-keys'): self.assertNotIn(cmd, self.tmux_log())
        self.assertFalse((self.wt/'BAD').exists())
    def test_claude_without_a_live_inbox_falls_back_to_paste(self):
        self.spawn('--agent', 'codex', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        for case, kwargs in (('no registry file', {'register': False}), ('recycled pid', {'proc_start': '1'})):
            with self.subTest(case):
                received = self.fake_claude(**kwargs); self.clear_log()
                x = self.report('PROGRESS', case)
                self.assertEqual(x.stdout, 'sent to parent (paste)\n'); self.assertRegex(self.last_report(), ' paste$')
                self.assertIn('paste-buffer', self.tmux_log()); self.assertEqual(received, [])
    def test_refused_inbox_fails_loudly_without_pasting(self):
        self.spawn('--agent', 'codex', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        self.fake_claude(listen=False); self.clear_log(); before = self.state()
        x = self.report('DONE', 'nobody home', ok=False)
        self.assert_delivery_failed(x, 'tmux:parent', 'claude inbox socket refused the connection', 'DONE', 'nobody home')
        self.assertNotIn('paste-buffer', self.tmux_log()); self.assertEqual(self.state(), before)
    def test_relay_delivers_to_a_claude_inbox(self):
        self.spawn('--agent', 'codex', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        received = self.fake_claude()
        x, log = self.run_relay('--allow', 'tmux:parent', ok=False, envelopes=[self.envelope('e9', 'target: tmux:parent\n\n[player far] DONE: over beam')])
        self.assertIn('relay.sh: delivered to tmux:parent (inbox)', x.stderr)
        self.assertEqual(json.loads(received[0])['message']['content'], '[player far] DONE: over beam')
        self.assertEqual(self.settled(log, 'msg.ack'), ['e9'])
    # A Claude orchestrator addressed by session id (claude:<sessionId>): no pane is involved. The
    # session is found in Claude's registry under the ORCHESTRATOR's config dir, recorded beside the
    # target at spawn, and nothing is ever pasted, whatever goes wrong.
    SID = '7c0ffee0-1234-4abc-8def-0123456789ab'
    def spawn_for_claude_session(self):
        cfg = self.base/'orchestrator-claude-config'; player_cfg = self.env['CLAUDE_CONFIG_DIR']
        self.env['CLAUDE_CONFIG_DIR'] = str(cfg); self.spawn('--agent', 'codex', '--orchestrator', 'claude:'+self.SID)
        self.env['CLAUDE_CONFIG_DIR'] = player_cfg                # the player runs with a different config dir
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'claude:'+self.SID)
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator-config'), str(cfg))
        return cfg
    def test_report_to_a_claude_session_goes_to_its_inbox_by_session_id(self):
        cfg = self.spawn_for_claude_session()
        self.fake_claude(config=cfg, session='0199a000-1111-7000-8000-00000000beef')   # another live session: never chosen
        received = self.fake_claude(config=cfg, session=self.SID); self.clear_log()
        text = 'one\ntwo "quoted" \\ back $(touch BAD)'
        x = self.report('DONE', text)
        self.assertEqual(x.stdout, 'sent to %s (inbox)\n' % self.SID)
        self.assertRegex(self.last_report(), '^DONE '+STAMP+' inbox$')
        self.wait_for(received); self.assertEqual(len(received), 1)
        self.assertEqual(json.loads(received[0]), {'type': 'user', 'message': {'role': 'user', 'content': '[player %s] DONE: %s' % (self.session, text)}})
        # no pane lookup of any kind: only the player's own tags are read and written
        commands = {c[0] for c in self.tmux_commands()}
        self.assertEqual(sorted(commands), ['display-message', 'set-option'])
        self.assertEqual(self.pane_lookups(), [])
        self.assertFalse((self.wt/'BAD').exists())
    def test_claude_session_config_dir_comes_from_the_tag_then_the_environment_then_home(self):
        cfg = self.spawn_for_claude_session(); self.fake_claude(config=cfg, session=self.SID)
        self.drop_tag('@session-x-orchestra-orchestrator-config')
        x = self.report('PROGRESS', 'player config dir', ok=False)        # the player's own dir has no such session
        self.assert_delivery_failed(x, 'claude:'+self.SID, 'no live Claude session %s is registered in %s/sessions' % (self.SID, self.env['CLAUDE_CONFIG_DIR']), 'PROGRESS', 'player config dir')
        self.assertEqual(self.report('PROGRESS', 'env', env=self.player_env(CLAUDE_CONFIG_DIR=str(cfg))).stdout, 'sent to %s (inbox)\n' % self.SID)
        import shutil; shutil.rmtree(cfg/'sessions')                                  # the fake inbox takes one connection
        home = self.base/'home'; home.mkdir(); (home/'.claude').symlink_to(cfg); self.fake_claude(config=cfg, session=self.SID)
        env = self.player_env(HOME=str(home)); del env['CLAUDE_CONFIG_DIR']
        self.assertEqual(self.report('PROGRESS', 'home', env=env).stdout, 'sent to %s (inbox)\n' % self.SID)
    def test_claude_session_target_fails_closed_and_never_pastes(self):
        import shutil
        cfg = self.spawn_for_claude_session(); missing = 'no live Claude session %s is registered in %s/sessions' % (self.SID, cfg)
        for case, kwargs, reason in (('not registered', {'register': False}, missing),
                                     ('recycled pid', {'proc_start': '1'}, missing),
                                     ('dead pid, live socket', {'register_pid': 2147483646, 'proc_start': False}, missing),
                                     ('another pid namespace', {'pid_domain': 'linux:00000000000000000000000000000000:pid:[1]'}, missing),
                                     ('socket refuses', {'listen': False}, 'claude inbox socket refused the connection')):
            with self.subTest(case):
                shutil.rmtree(cfg/'sessions', ignore_errors=True)
                received = self.fake_claude(config=cfg, session=self.SID, **kwargs); self.clear_log(); before = self.state()
                x = self.report('DONE', case, ok=False)
                self.assert_delivery_failed(x, 'claude:'+self.SID, reason, 'DONE', case)
                for cmd in ('load-buffer', 'paste-buffer', 'send-keys'): self.assertNotIn(cmd, self.tmux_log())
                self.assertEqual(self.pane_lookups(), [])
                self.assertEqual(self.state(), before); self.assertEqual(received, [])
    # display-message calls that ask about anything but the session's own tags.
    def pane_lookups(self):
        return [c for c in self.tmux_commands() if c[0] == 'display-message' and re.sub(r'#\{@[^}]*\}|\t', '', c[-1])]
    def own_claude_session(self, session=None):
        # The environment a Claude Code session gives the commands it runs: its session id, its pid
        # (registered under its config dir) and CLAUDECODE; here also a tmux pane that is not its own.
        cfg = self.base/'orchestrator-claude-config'
        self.fake_claude(config=cfg, session=session or self.SID)
        self.env.update(CLAUDECODE='1', CLAUDE_CODE_SESSION_ID=self.SID, CLAUDE_PID=str(self.fake_claude_pid), CLAUDE_CONFIG_DIR=str(cfg))
        return cfg
    def test_claude_orchestrator_is_detected_by_its_verified_session_id(self):
        script = '. "$1"; resolve_orchestrator "${2:-}"'
        def resolve(explicit=''): return self.run_cmd(['bash', '-c', script, 'test', str(ROOT/'player/scripts/_routing.sh'), explicit], ok=False)
        self.own_claude_session(); self.env.update(TMUX='/tmp/someone-elses,1,1', TEST_TMUX_SESSION='kirby-shell-2')
        self.assertEqual(resolve().stdout, 'claude:'+self.SID)                           # wins over tmux and inherited Codex IDs
        self.assertEqual(resolve('tmux:parent').stdout, 'tmux:parent')                    # an explicit target still wins
        self.own_claude_session(session='0199a000-1111-7000-8000-00000000beef')          # CLAUDE_PID's registry entry is another session
        x = resolve(); self.assertEqual(x.returncode, 2); self.assertEqual(x.stdout, '')
        self.assertIn('CLAUDE_CODE_SESSION_ID %s is not the session registered' % self.SID, x.stderr)
        self.env['CLAUDE_PID'] = '2147483646'; x = resolve(); self.assertEqual(x.returncode, 2); self.assertIn('pass --orchestrator', x.stderr)
    def test_spawn_and_adopt_from_a_claude_orchestrator_record_its_session_and_config(self):
        cfg = self.own_claude_session(); self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'codex')
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'claude:'+self.SID); self.assertEqual(self.tag('@session-x-orchestra-orchestrator-config'), str(cfg))
        e = self.calls()[-1]['env']; self.assertIsNone(e['CLAUDECODE'])                 # nothing of the orchestrator's session reaches the player
        self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:p')
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'tmux:p'); self.assertIsNone(self.tag('@session-x-orchestra-orchestrator-config'))
        self.orch('adopt.sh', self.session)
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'claude:'+self.SID); self.assertEqual(self.tag('@session-x-orchestra-orchestrator-config'), str(cfg))
        self.env['CLAUDE_CODE_SESSION_ID'] = '0199a000-1111-7000-8000-00000000beef'     # unverifiable: nothing is changed or created
        x = self.orch('adopt.sh', self.session, ok=False); self.assertEqual(x.returncode, 2)
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'claude:'+self.SID)
        x = self.spawn('--agent', 'codex', branch='feature/other', ok=False); self.assertEqual(x.returncode, 2)
        self.assertEqual(sorted(self.state()), [self.session])
    def test_spawn_and_adopt_mark_the_orchestrators_own_session_with_its_target(self):
        # A Claude orchestrator inside tmux (a terminal tab where `claude` was run by hand): its
        # players carry claude:<id>, which names no session, so its own session is marked with it.
        sock = '/tmp/orchestrator-sock'; self.foreign('kirby-shell-2', sock=sock)
        self.own_claude_session(); self.env.update(TMUX=sock+',1,1', TEST_TMUX_SESSION='kirby-shell-2')
        self.spawn('--agent', 'codex')
        self.assertEqual(self.tag('@session-x-orchestra-target', 'kirby-shell-2', sock=sock), 'claude:'+self.SID)
        self.assertIsNone(self.tag('@session-x-orchestra-target', sock=sock))                     # never on the player itself
    def test_adopt_marks_the_orchestrators_own_session_unless_handing_off(self):
        self.own_claude_session(); self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'codex')                                                   # outside tmux: nothing to mark
        self.foreign('claude-tab', sock='/tmp/orchestrator-sock')
        self.env.update(TMUX='/tmp/orchestrator-sock,1,1', TEST_TMUX_SESSION='claude-tab')
        self.orch('adopt.sh', self.session, '--orchestrator', 'claude:'+UUID)             # a handoff to another conversation
        self.assertIsNone(self.tag('@session-x-orchestra-target', 'claude-tab', sock='/tmp/orchestrator-sock'))
        self.orch('adopt.sh', self.session)
        self.assertEqual(self.tag('@session-x-orchestra-target', 'claude-tab', sock='/tmp/orchestrator-sock'), 'claude:'+self.SID)
    def test_a_codex_orchestrator_in_tmux_is_marked_and_another_or_a_tmux_target_is_not(self):
        sock = '/tmp/orchestrator-sock'; self.foreign('codex-tab', sock=sock)
        self.env.update(TMUX=sock+',1,1', TEST_TMUX_SESSION='codex-tab')
        self.spawn('--agent', 'codex')
        self.assertEqual(self.tag('@session-x-orchestra-target', 'codex-tab', sock=sock), 'codex:'+ID)
        self.drop_tag_of_on(sock, 'codex-tab', '@session-x-orchestra-target')
        self.spawn('--agent', 'codex', '--orchestrator', 'codex:'+UUID, branch='feature/someone-else')   # a handoff
        self.assertIsNone(self.tag('@session-x-orchestra-target', 'codex-tab', sock=sock))
        self.spawn('--agent', 'codex', '--orchestrator', 'codex:'+ID, branch='feature/explicit-self')    # its own id, given explicitly
        self.assertEqual(self.tag('@session-x-orchestra-target', 'codex-tab', sock=sock), 'codex:'+ID)
        self.drop_tag_of_on(sock, 'codex-tab', '@session-x-orchestra-target')
        self.env.pop('CODEX_THREAD_ID'); self.env.pop('CODEX_SESSION_ID')               # resolves to tmux:codex-tab, which names itself
        self.spawn('--agent', 'codex', branch='feature/tmux')
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator', 'repo-feature-tmux', sock=sock), 'tmux:codex-tab')
        self.assertIsNone(self.tag('@session-x-orchestra-target', 'codex-tab', sock=sock))
    def test_a_claude_orchestrator_giving_its_own_id_explicitly_is_marked(self):
        sock = '/tmp/orchestrator-sock'; self.foreign('claude-tab', sock=sock)
        self.own_claude_session(); self.env.update(TMUX=sock+',1,1', TEST_TMUX_SESSION='claude-tab')
        self.spawn('--agent', 'codex', '--orchestrator', 'claude:'+self.SID)
        self.assertEqual(self.tag('@session-x-orchestra-target', 'claude-tab', sock=sock), 'claude:'+self.SID)
        self.drop_tag_of_on(sock, 'claude-tab', '@session-x-orchestra-target')
        self.spawn('--agent', 'codex', '--orchestrator', 'codex:'+ID, branch='feature/inherited')   # an inherited Codex id is not Claude's own
        self.assertIsNone(self.tag('@session-x-orchestra-target', 'claude-tab', sock=sock))
    def test_a_conversation_resumed_in_another_session_leaves_one_claimant(self):
        sock = '/tmp/orchestrator-sock'
        self.foreign('first-tab', {'@session-x-orchestra-target': 'codex:'+ID}, sock=sock)     # where the conversation ran before
        self.foreign('unrelated', {'@session-x-orchestra-target': 'codex:'+UUID}, sock=sock)
        self.foreign('resumed-tab', sock=sock)
        self.env.update(TMUX=sock+',1,1', TEST_TMUX_SESSION='resumed-tab')
        self.spawn('--agent', 'codex')
        self.assertEqual(self.tag('@session-x-orchestra-target', 'resumed-tab', sock=sock), 'codex:'+ID)
        self.assertIsNone(self.tag('@session-x-orchestra-target', 'first-tab', sock=sock))
        self.assertEqual(self.tag('@session-x-orchestra-target', 'unrelated', sock=sock), 'codex:'+UUID)
    def test_an_orchestrator_outside_tmux_marks_nothing(self):
        self.spawn('--agent', 'codex')
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'codex:'+ID)
        self.assertEqual([c for c in self.tmux_commands() if c[0] == 'set-option' and (c[-1] if '-u' in c else c[-2]).endswith('-target')], [])
    def drop_tag_of_on(self, sock, session, name):
        s = self.state(sock); s[session]['options'].pop(name, None); self.set_state(s, sock)
    def test_relay_delivers_to_a_claude_session_by_id(self):
        received = self.fake_claude(session=self.SID)                                    # under the relay's own config dir
        x, log = self.run_relay('--allow', 'claude:'+self.SID, ok=False,
                                envelopes=[self.envelope('e10', 'target: claude:%s\n\n[player far] DONE: to a session' % self.SID)])
        self.assertIn('relay.sh: delivered to claude:%s (inbox)' % self.SID, x.stderr)
        self.wait_for(received); self.assertEqual(json.loads(received[0])['message']['content'], '[player far] DONE: to a session')
        self.assertEqual(self.settled(log, 'msg.ack'), ['e10'])
        x = self.orch('relay.sh', '--allow', 'claude:not-a-uuid', cwd=self.base, ok=False); self.assertEqual(x.returncode, 2)
    def test_relay_default_allowlist_is_the_claude_session_it_runs_in(self):
        # Inside Claude, $TMUX may name someone else's session; the relay's own session id wins.
        received = self.fake_claude(session=self.SID); self.foreign('parent', sock='/tmp/relay-sock')
        env = dict(self.env, CLAUDE_CODE_SESSION_ID=self.SID, TMUX='/tmp/relay-sock,0,0', TEST_TMUX_SESSION='parent')
        x, log = self.run_relay(env=env, ok=False, envelopes=[self.envelope('e11', 'target: tmux:parent\n\nnot mine'),
                                                              self.envelope('e12', 'target: claude:%s\n\nmine' % self.SID)])
        self.assertIn('may deliver to: claude:%s on' % self.SID, x.stderr)
        self.assertEqual(self.settled(log, 'msg.defer'), ['e11']); self.assertEqual(self.settled(log, 'msg.ack'), ['e12'])
    def test_report_beam_target_carries_a_claude_session(self):
        self.spawn('--agent', 'codex'); self.stub('beam', BEAM_MOCK); self.env['TEST_BEAM_OUTCOME'] = 'delivered'
        self.run_cmd(['tmux', 'set-option', '-t', '='+self.session+':', '@session-x-orchestra-orchestrator', 'beam:%s/claude:%s' % (PEER, self.SID)])
        self.assertEqual(self.report('DONE', 'far').stdout, 'sent to %s\n' % PEER)
        self.assertEqual(self.beam_sent()[-1]['payload'], 'target: claude:%s\n\n[player %s] DONE: far' % (self.SID, self.session))
    def test_send_to_a_claude_player_goes_to_its_inbox(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'claude')
        received = self.fake_claude(); self.clear_log()
        x = self.orch('send.sh', self.session, 'use the second approach\nand "quote" it')
        self.assertEqual(x.stdout, 'sent to %s (inbox)\n' % self.session)
        for _ in range(100):
            if received: break
            import time; time.sleep(0.05)
        self.assertEqual(json.loads(received[0]), {'type': 'user', 'message': {'role': 'user', 'content': '[orchestrator] use the second approach\nand "quote" it'}})
        for cmd in ('load-buffer', 'paste-buffer', 'send-keys'): self.assertNotIn(cmd, self.tmux_log())
        # --raw, --key and --type stay keystrokes into the pane, Claude or not
        self.clear_log(); x = self.orch('send.sh', self.session, '--raw', '1')
        self.assertEqual(x.stdout, 'sent to %s (paste)\n' % self.session); self.assertIn('paste-buffer', self.tmux_log())
        self.assertEqual((self.base/'buffer').read_text(), '1')
    def test_send_to_other_players_pastes(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        for command in ('codex', 'claude', 'bash'):                 # codex; a Claude with no registered inbox; a shell
            with self.subTest(command):
                self.env['TEST_PANE_COMMAND'] = command; self.clear_log()
                x = self.orch('send.sh', self.session, 'nudge')
                self.assertEqual(x.stdout, 'sent to %s (paste)\n' % self.session); self.assertIn('paste-buffer', self.tmux_log())
                self.assertEqual((self.base/'buffer').read_text(), '[orchestrator] nudge')
    # A Codex TUI: its thread id is the UUID of the rollout file it holds open; a subagent's
    # rollout (parent_thread_id set) is open too and must not be mistaken for it.
    THREAD = '01a0ce78-3bf1-7152-9fd0-e460736488f0'
    def fake_codex(self, rollout=True):
        home = self.base/'player-codex-home'; d = home/'sessions/2026/09/23'; d.mkdir(parents=True, exist_ok=True)
        main = d/('rollout-2026-09-23T13-33-01-%s.jsonl' % self.THREAD)
        guardian = d/'rollout-2026-09-23T13-33-01-01a0ce78-4444-7000-8000-000000000001.jsonl'
        meta = lambda i, extra: json.dumps({'timestamp': 't', 'type': 'session_meta', 'payload': dict({'session_id': self.THREAD, 'id': i, 'cwd': str(self.wt)}, **extra)})
        main.write_text(meta(self.THREAD, {'source': 'cli'})+'\n')
        guardian.write_text(meta('01a0ce78-4444-7000-8000-000000000001', {'parent_thread_id': self.THREAD})+'\n')
        files = [str(guardian), str(main)] if rollout else ['/dev/null', '/dev/null']
        proc = subprocess.Popen(['bash', '-c', 'exec 3<"$0" 4<"$1"; exec -a codex sleep 30', *files], stdin=subprocess.DEVNULL)
        self.addCleanup(proc.wait); self.addCleanup(proc.kill)
        import time
        for _ in range(100):
            if Path('/proc/%d/cmdline' % proc.pid).read_bytes().split(b'\0')[0] == b'codex': break
            time.sleep(0.02)
        self.env.update(TEST_PANE_COMMAND='codex', TEST_PANE_PID=str(proc.pid))
        return home
    def test_send_and_adopt_queue_to_a_codex_player_by_its_thread(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        home = self.fake_codex(); self.clear_log(); n = len(self.calls())
        x = self.orch('send.sh', self.session, 'try the other flag')
        self.assertEqual(x.stdout, 'sent to %s (queue)\n' % self.session)
        c = self.calls()[-1]
        self.assertEqual(c['args'], ['queue', '--thread', self.THREAD, '--message', '[orchestrator] try the other flag'])
        self.assertEqual(c['env']['CODEX_HOME'], str(home))                 # the TUI's own CODEX_HOME, from the rollout path
        x = self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:new-parent', 'Next', 'task')
        self.assertTrue(x.stdout.rstrip().endswith('via queue'), x.stdout)
        self.assertEqual(self.calls()[-1]['args'], ['queue', '--thread', self.THREAD, '--message', '$player Next task'])
        self.assertEqual(len(self.calls()), n+2)
        for cmd in ('load-buffer', 'paste-buffer', 'send-keys'): self.assertNotIn(cmd, self.tmux_log())
    def test_report_to_a_codex_orchestrator_in_tmux_queues(self):
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        self.fake_codex(); self.clear_log()
        x = self.report('DONE', 'queued to a codex tui')
        self.assertEqual(x.stdout, 'sent to parent (queue)\n'); self.assertRegex(self.last_report(), ' queue$')
        self.assertEqual(self.calls()[-1]['args'], ['queue', '--thread', self.THREAD, '--message', '[player %s] DONE: queued to a codex tui' % self.session])
    def test_codex_without_a_thread_is_pasted_and_a_refused_queue_is_final(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        self.fake_codex(rollout=False); self.clear_log(); n = len(self.calls())       # before its first turn: no rollout
        x = self.orch('send.sh', self.session, 'hello')
        self.assertEqual(x.stdout, 'sent to %s (paste)\n' % self.session); self.assertEqual(len(self.calls()), n)
        x = self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:p')
        self.assertTrue(x.stdout.rstrip().endswith('via keys'), x.stdout); self.assertIn('"-l", "$player"]', self.tmux_log())
        self.fake_codex(); self.env['TEST_CODEX_EXIT'] = '1'; self.clear_log()
        x = self.orch('send.sh', self.session, 'refused', ok=False)
        self.assertEqual(x.returncode, 1); self.assertIn('codex queue refused the message for thread '+self.THREAD, x.stderr)
        self.assertNotIn('paste-buffer', self.tmux_log())
    def test_adopt_types_the_invocation_for_claude_even_with_a_live_inbox(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'claude')
        received = self.fake_claude(); self.clear_log()
        x = self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:p', 'New', 'task')
        self.assertTrue(x.stdout.rstrip().endswith('via keys'), x.stdout)
        self.assertIn('"-l", "%s New task"]' % INV, self.tmux_log()); self.assertEqual(received, [])
    def test_failed_paste_leaves_no_buffer(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        self.env['TEST_PASTE_FAIL'] = '1'
        x = self.orch('send.sh', self.session, 'hello', ok=False); self.assertNotEqual(x.returncode, 0); self.assertEqual(self.buffers(), {})
        x = self.report('DONE', 'lost', ok=False); self.assertIn('report.sh: delivery failed', x.stderr); self.assertEqual(self.buffers(), {})
        # paste and the cleanup both fail (server gone in between): the full error must still reach the player
        self.env['TEST_DELETE_FAIL'] = '1'
        x = self.report('DONE', 'doubly lost', ok=False); self.assertEqual(x.returncode, 1)
        self.assert_delivery_failed(x, 'tmux:parent', 'tmux could not paste', 'DONE', 'doubly lost')
        x = self.orch('send.sh', self.session, 'hello', ok=False); self.assertNotEqual(x.returncode, 0); self.assertIn('could not paste', x.stderr)
    def test_shell_owned_parent_prints_failure(self):
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        self.env['TEST_PANE_COMMAND'] = 'bash'; x = self.report('QUESTION', 'decision', ok=False)
        self.assertNotEqual(x.returncode, 0); self.assertNotIn('paste-buffer', self.tmux_log()); self.assertIn('a shell owns', x.stderr)
        self.assert_delivery_failed(x, 'tmux:parent', 'a shell owns', 'QUESTION', 'decision')
    def test_no_parent_never_uses_player_id(self):
        self.spawn('--agent', 'claude'); self.drop_tag('@session-x-orchestra-orchestrator'); n = len(self.calls())
        x = self.report('DONE', 'no parent', ok=False); self.assertNotEqual(x.returncode, 0); self.assertEqual(len(self.calls()), n)
        self.assert_delivery_failed(x, '<unknown>', 'orchestrator target is unset or unreachable', 'DONE', 'no parent')

    # --- routing, adoption, listing, exact targeting -----------------------------------------
    def test_detection(self):
        script = '. "$1"; resolve_orchestrator "${2:-}"'
        def resolve(explicit=''): return self.run_cmd(['bash', '-c', script, 'test', str(ROOT/'player/scripts/_routing.sh'), explicit], ok=False)
        self.env['TMUX'] = '/tmp/custom,1,1'; self.assertEqual(resolve().stdout, 'codex:'+ID)
        self.assertEqual(resolve('tmux:parent').stdout, 'tmux:parent')
        self.assertNotEqual(resolve('parent').returncode, 0)                                  # bare names are not accepted
        self.env['CLAUDECODE'] = '1'; self.assertEqual(resolve().stdout, 'tmux:parent')      # a Claude orchestrator ignores inherited Codex IDs
        del self.env['TMUX']; self.assertNotEqual(resolve().returncode, 0)
        self.assertEqual(resolve('codex:'+ID).stdout, 'codex:'+ID)
        del self.env['CLAUDECODE']; self.env.pop('CODEX_THREAD_ID'); self.env.pop('CODEX_SESSION_ID'); self.assertNotEqual(resolve().returncode, 0)
    def test_adopt_codex_player_with_and_without_text(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:new-parent')
        self.assertIn('"-l", "$player"]', self.tmux_log()); self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'tmux:new-parent')
        self.assertEqual(self.report('--orchestrator').stdout.strip(), 'tmux:new-parent')
        self.orch('adopt.sh', 'feature/test', '--repo', str(self.repo), '--orchestrator', 'tmux:new-parent', 'Now', 'do', 'this')
        self.assertIn('"-l", "$player Now do this"]', self.tmux_log()); self.assert_no_state_files(); self.assert_reads_pass_utf8()
    def test_adopt_refuses_dead_or_shell_pane(self):
        self.spawn('--agent', 'claude')          # mock CLI exits, so the pane is dead
        x = self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:p', ok=False); self.assertIn('dead', x.stderr)
        self.env['TEST_PANE_ALIVE'] = '1'; self.env['TEST_PANE_COMMAND'] = 'bash'; self.kill_pane(); self.spawn('--resume', prompt=False)
        self.clear_log(); x = self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:p', ok=False)
        self.assertIn('shell owns', x.stderr); self.assertNotIn('send-keys', self.tmux_log()); self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'codex:'+ID)
    def test_sessions_lists_tags(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex')
        for extra in ([], ['--all']):
            rows = self.sessions(*extra); self.assertEqual(len(rows), 1); r = rows[0]
            self.assertEqual((r['session'], r['name'], r['agent'], r['orchestrator'], r['last_report'], r['branch'], r['repo']),
                             (self.session, self.session, 'codex', 'codex:'+ID, '', 'feature/test', str(self.repo.resolve())))
        self.report('DONE', 'finished')
        r = self.sessions('--all')[0]; self.assertRegex(r['last_report'], '^DONE '+STAMP+' delivered$')
        self.env['TEST_PANE_TITLE'] = 'left\tright'
        r = self.sessions('--all')[0]; self.assertEqual(r['title'], 'left\tright'); del self.env['TEST_PANE_TITLE']
        text = self.orch('sessions.sh', '--all').stdout.splitlines()
        self.assertIn('AGENT', text[0]); self.assertIn('ORCHESTRATOR', text[0]); self.assertIn('LAST-REPORT', text[0])
        self.assertIn('codex', text[1]); self.assertIn('codex:'+ID, text[1]); self.assertIn('DONE ', text[1])
    def test_exact_session_targeting(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'claude')
        self.spawn('--prompt', 'p', prompt=False, branch='feature/test-2')
        self.clear_log(); self.orch('send.sh', 'feature/test', '--repo', str(self.repo), 'hello')
        self.assertIn('"=%s:"' % self.session, self.tmux_log()); self.assertNotIn('feature-test-2', self.tmux_log()); self.assertEqual((self.base/'buffer').read_text(), '[orchestrator] hello')
        for s in ('screen.sh', 'kill.sh'):
            x = self.orch(s, 'feature', '--repo', str(self.repo), ok=False); self.assertNotEqual(x.returncode, 0)
            x = self.orch(s, 'feature-test', '--repo', str(self.repo), ok=False); self.assertNotEqual(x.returncode, 0)     # a sanitized branch is neither a name nor a branch
        self.orch('send.sh', self.session, 'y'*30000)          # over tmux's command limit: goes through load-buffer
        s2 = 'repo-feature-test-2'
        self.run_cmd(['tmux', 'load-buffer', '-b', 'orchestra-prompt-'+s2, '-'], stdin='leftover\n'); self.assertIn('orchestra-prompt-'+s2, self.buffers())
        self.orch('kill.sh', 'feature/test-2', '--repo', str(self.repo))
        self.assertEqual(sorted(self.state()), [self.session]); self.assertEqual(self.buffers(), {})
        self.orch('screen.sh', 'feature/test', '--repo', str(self.repo)); self.assert_reads_pass_utf8()

    # --- machines: the executor, beam-qualified targets, relay ------------------------------
    # Every tmux invocation a LOCAL run (no --machine anywhere) may make, pinned: command -> the
    # exact flags that precede it. Three shapes, and no others. "-u" is deliberate and intended
    # wherever tmux_on carries it, capture-pane included: it is what makes tmux print real tabs
    # and non-ASCII instead of "_" outside a UTF-8 locale (see tmux_on in _routing.sh), so the
    # pane text screen.sh reads back is the pane's, whatever the caller's locale. The two sites
    # that do not go through tmux_on keep their own argv: spawn.sh starts the tmux server itself,
    # marker-stripped, and _launch.sh reads its prompt buffer from inside the pane.
    LOCAL_TMUX_ARGV = {
        'capture-pane':   [('-u',)],
        'delete-buffer':  [('-u',), ('-S', 'SOCK')],
        'display-message': [('-u',), ('-u', '-S', 'SOCK')],    # the launcher reads its session's record
        'has-session':    [('-u',), ('-u', '-S', 'SOCK')],
        'kill-session':   [('-u',)],
        'list-panes':     [('-u',)],
        'list-sessions':  [('-u',)],
        'load-buffer':    [('-u',), ('-u', '-S', 'SOCK')],
        'new-session':    [('-S', 'SOCK')],
        'paste-buffer':   [('-u',)],
        'respawn-pane':   [('-u', '-S', 'SOCK')],
        'send-keys':      [('-u',)],
        'set-option':     [('-u',), ('-u', '-S', 'SOCK')],
        'show-buffer':    [('-S', 'SOCK')],
    }
    def test_local_tmux_argv_is_pinned_at_every_call_site(self):
        # The machine dimension moved call sites that used a bare `tmux` — kill-session and
        # delete-buffer in kill.sh, send-keys in send.sh and adopt.sh, and has-session,
        # capture-pane, display-message and the whole paste_into sequence in _lib.sh — onto
        # tmux_on, which has always passed -u. Pinning only spawn.sh's new-session left that
        # unchecked, so this exercises each of them and pins the argv they are meant to have,
        # -u and all: an unintended change to a local invocation fails here.
        self.env['TEST_PANE_ALIVE'] = '1'
        self.spawn('--agent', 'codex')                                          # new-session, tags, prompt buffer, launcher
        self.orch('sessions.sh', '--repo', str(self.repo))                      # list-panes
        self.orch('screen.sh', self.session, '--repo', str(self.repo))          # capture-pane, display-message
        self.orch('send.sh', self.session, '--repo', str(self.repo), 'hello')   # paste_into
        self.orch('send.sh', self.session, '--repo', str(self.repo), '--type', 'hi')
        self.orch('adopt.sh', self.session, '--repo', str(self.repo), '--orchestrator', 'tmux:parent')
        self.orch('kill.sh', self.session, '--repo', str(self.repo))            # kill-session, delete-buffer
        seen = {}
        for c in self.tmux_calls():
            flags, i = [], 0
            while c[i:i+1] in (['-u'], ['-S']):
                if c[i] == '-u': flags.append('-u'); i += 1
                else:
                    self.assertEqual(c[i+1], self.sock, c)      # never a server this run did not choose
                    flags += ['-S', 'SOCK']; i += 2
            seen.setdefault(c[i], set()).add(tuple(flags))
        self.assertEqual({k: sorted(v) for k, v in sorted(seen.items())},
                         {k: sorted(v) for k, v in sorted(self.LOCAL_TMUX_ARGV.items())})
    def test_machine_flag_routes_through_beam_exec_with_large_stdin(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex'); self.stub('beam', BEAM_MOCK)
        big = 'y' * 20000       # over tmux's ~16 KiB command-line cap: only load-buffer on stdin survives
        x = self.orch('send.sh', self.session, '--machine', 'workbox', big)
        self.assertEqual(x.returncode, 0, x.stderr)
        exec_calls = [c for c in self.beam_calls() if c[:1] == ['exec']]
        self.assertTrue(exec_calls, self.beam_calls())
        load = next(c for c in exec_calls if 'load-buffer' in c)
        # Every remote tmux call names the server explicitly: a beam exec inherits no $TMUX, so
        # without -S the target's tmux would pick its own default and answer for a different
        # server than the one spawn.sh created the session on.
        self.assertEqual(load, ['exec', 'workbox', '--', 'tmux', '-u', '-S', self.sock, 'load-buffer', '-b', load[-2], '-'])
        self.assertEqual(sum(c[3:5] == ['sh', '-c'] for c in exec_calls), 1, exec_calls)   # asked once, then cached
        self.assertEqual((self.base/'buffer').read_text(), '[orchestrator] ' + big)     # stdin reached the mock intact
    def test_missing_beam_binary_fails_names_both_options_and_runs_nothing_locally(self):
        calls_before = len(self.tmux_calls())
        # Only the stubs and the system directories: a beam installed on the host running the
        # suite must not resolve here, and neither may an n10 binary stand in for it.
        (self.bin/'beam').unlink(); self.stub('n10', CLI_MOCK); env = dict(self.env, PATH=str(self.bin)+':/usr/bin:/bin')
        x = self.run_cmd(['bash', '-c', '. "$0"; ORCH_MACHINE=ghost tmux_on "" list-sessions', self.script('_lib.sh')], cwd=self.base, ok=False, env=env)
        self.assertNotEqual(x.returncode, 0)
        self.assertIn('$ORCHESTRA_BEAM', x.stderr); self.assertIn("'beam' on PATH", x.stderr); self.assertNotIn('n10', x.stderr)
        self.assertEqual(self.calls(), [])
        self.assertIn('refusing to run this locally', x.stderr)
        self.assertEqual(len(self.tmux_calls()), calls_before)
    def test_relative_repo_with_machine_rejected(self):
        self.stub('beam', BEAM_MOCK)
        x = self.orch('spawn.sh', '--repo', 'relative/path', '--machine', 'workbox', '--branch', 'feature/x', '--prompt', 'p', ok=False)
        self.assertNotEqual(x.returncode, 0)
        self.assertIn('--repo must be an absolute path or start with ~/', x.stderr)
        self.assertEqual(self.beam_calls(), [])          # rejected before anything reached the executor
    def test_report_beam_target_delivered_stored_rejected(self):
        self.spawn('--agent', 'codex'); self.stub('beam', BEAM_MOCK)
        self.run_cmd(['tmux', 'set-option', '-t', '='+self.session+':', '@session-x-orchestra-orchestrator', 'beam:%s/tmux:controller' % PEER])
        self.env['TEST_BEAM_OUTCOME'] = 'delivered'
        x = self.report('DONE', 'finished work')
        self.assertEqual(x.returncode, 0); self.assertEqual(x.stdout, 'sent to %s\n' % PEER)
        self.assertRegex(self.last_report(), r'^DONE '+STAMP+r' delivered$')
        self.assertEqual(self.beam_calls()[-1], ['msg', 'send', PEER, '--topic', 'orchestra', '-'])    # payload on stdin, positional "-"
        sent = self.beam_sent()[-1]
        self.assertEqual(sent['peer'], PEER)
        self.assertEqual(sent['payload'], 'target: tmux:controller\n\n[player %s] DONE: finished work' % self.session)

        # stored is success: on this machine's disk, delivery pending; beam/docs/05's exact sentence.
        for outcome, sentence in (
                ('stored-offline', 'stored for {0}; delivery pending ({0} is offline). beam will deliver it when {0} connects. Do not send it again.\n'),
                ('stored-no-ack', 'stored for {0}; delivery pending ({0} has not acknowledged it). beam will keep delivering it until {0} does. Do not send it again.\n')):
            with self.subTest(outcome=outcome):
                self.env['TEST_BEAM_OUTCOME'] = outcome
                x = self.report('PROGRESS', 'still going')
                self.assertEqual(x.returncode, 0); self.assertEqual(x.stdout, sentence.format(PEER))
                self.assertRegex(self.last_report(), r'^PROGRESS '+STAMP+r' stored$')

        self.env['TEST_BEAM_OUTCOME'] = 'rejected'; self.env['TEST_BEAM_REJECT_REASON'] = 'unknown-peer'
        before = self.state()
        x = self.report('BLOCKED', 'need input', ok=False)
        self.assert_delivery_failed(x, 'beam:%s/tmux:controller' % PEER, 'beam rejected the message (exit 1): unknown-peer', 'BLOCKED', 'need input')
        self.assertEqual(self.state(), before)      # rejected: nothing was stored, no session write, no retry
    def test_last_report_third_field_backward_compatible(self):
        self.spawn('--agent', 'codex'); self.report('DONE', 'ok')
        val = self.last_report(); self.assertRegex(val, r'^DONE '+STAMP+r' delivered$')
        kind, ts = val.split()[:2]          # a parser reading only the first two fields still works
        self.assertEqual(kind, 'DONE'); self.assertRegex(ts, r'^'+STAMP+r'$')
    def test_normalize_target_beam_qualified(self):
        def norm(t): return self.run_cmd(['bash', '-c', '. "$0"; normalize_target "$1"', str(ROOT/'player/scripts/_routing.sh'), t], ok=False)
        for good in ('beam:%s/tmux:controller' % PEER, 'beam:%s/codex:%s' % (PEER, ID), 'claude:'+ID, 'beam:%s/claude:%s' % (PEER, ID)):
            x = norm(good); self.assertEqual(x.returncode, 0, good); self.assertEqual(x.stdout, good)
        for bad in ('beam:/tmux:controller', 'beam:%s' % PEER, 'beam:%s/ssh:host' % PEER,
                    'beam:%s/tmux:se:ss' % PEER, 'beam:%s/tmux:se\nss' % PEER, 'beam:1234/tmux:controller', 'beam:%s/tmux:controller' % PEER.upper(), 'beam:%s/tmux:controller' % PEER[:16], 'ssh:host',
                    'claude:', 'claude:not-a-uuid', 'claude:%s/x' % ID, 'beam:%s/claude:nope' % PEER):
            x = norm(bad); self.assertNotEqual(x.returncode, 0, bad)
    def envelope(self, id, payload, frm='p', encoding='utf8'):
        return {'id': id, 'from': frm, 'to': PEER, 'seq': 1, 'topic': 'orchestra', 'payload': payload, 'encoding': encoding, 'createdAt': 0}
    def test_relay_subscribes_on_the_control_socket_and_acks_after_delivery(self):
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); self.foreign('parent'); self.clear_log()
        x, log = self.run_relay('--allow', 'tmux:parent', ok=False,
                                envelopes=[self.envelope('e1', 'target: tmux:parent\n\n[player %s] DONE: relayed' % self.session)])
        self.assertEqual(x.returncode, 1); self.assertIn('the beam daemon closed the connection', x.stderr)     # daemon gone: exit 1, nothing lost
        # parameters sit beside "op"; a nested "params" object would be ignored and subscribe to every topic
        self.assertEqual(log[0], (1, {'id': 1, 'op': 'msg.subscribe', 'topic': 'orchestra'}))
        self.assertIn('relay.sh: delivered to tmux:parent', x.stderr)
        self.assertEqual((self.base/'buffer').read_text(), '[player %s] DONE: relayed' % self.session)
        self.assertEqual(log[1], (1, {'id': 2, 'op': 'msg.ack', 'envelopeId': 'e1'}))
        self.assertEqual(self.settled(log, 'msg.defer'), [])
    def test_relay_delivers_to_codex_target(self):
        _, log = self.run_relay('--allow', 'codex:'+ID, ok=False, envelopes=[self.envelope('e2', 'target: codex:%s\n\nhello from relay' % ID)])
        self.assertEqual(self.calls()[-1]['args'], ['queue', '--thread', ID, '--message', 'hello from relay'])
        self.assertEqual(self.settled(log, 'msg.ack'), ['e2'])
    def test_relay_settles_each_envelope_before_the_next(self):
        envs = [self.envelope('e%d' % i, 'target: codex:%s\n\nreport %d' % (ID, i)) for i in range(3)]
        _, log = self.run_relay('--allow', 'codex:'+ID, ok=False, envelopes=envs)
        self.assertEqual([c['args'][-1] for c in self.calls()], ['report 0', 'report 1', 'report 2'])
        self.assertEqual(self.settled(log, 'msg.ack'), ['e0', 'e1', 'e2'])
    def test_relay_decodes_unpadded_base64url_payload(self):
        import base64
        msg = 'target: codex:%s\n\nb64 message ?>~ with /+ \u00e9' % ID
        raw = base64.urlsafe_b64encode(msg.encode()).decode().rstrip('=')
        self.assertIn('-', raw + base64.urlsafe_b64encode(b'\xfb\xff').decode())      # the alphabet differs from standard base64
        _, log = self.run_relay('--allow', 'codex:'+ID, ok=False, envelopes=[self.envelope('e3', raw, encoding='base64'),
                                                                               self.envelope('e3b', 'not*base64', encoding='base64')])
        self.assertEqual(self.calls()[-1]['args'][4], 'b64 message ?>~ with /+ \u00e9')
        self.assertEqual(self.settled(log, 'msg.ack'), ['e3']); self.assertEqual(self.settled(log, 'msg.defer'), ['e3b'])
    def test_relay_defers_a_failed_delivery_and_retries_on_a_new_subscription(self):
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent'); self.foreign('parent')
        self.env['TEST_PANE_COMMAND'] = 'bash'; self.clear_log()
        x, log = self.run_relay('--allow', 'tmux:parent', ok=False, env=dict(self.env, ORCHESTRA_RELAY_RETRY='1'),
                                envelopes=[self.envelope('e4', 'target: tmux:parent\n\n[player x] DONE: hi')],
                                beamd_connections=2, beamd_hold=3)
        self.assertIn('a shell owns', x.stderr); self.assertNotIn('paste-buffer', self.tmux_log())
        self.assertEqual(self.settled(log, 'msg.ack'), [])                      # never acked: the report is not lost
        defers = [(c, r) for c, r in log if r.get('op') == 'msg.defer']
        self.assertEqual([c for c, _ in defers], [1, 2])                       # deferred, then offered again to the next subscription
        self.assertIn('a shell owns parent now', defers[0][1]['reason'])
        self.assertEqual([r['op'] for c, r in log if c == 2][0], 'msg.subscribe')
    def test_relay_default_allowlist_is_its_own_session_only(self):
        # With no --allow, the only permitted target is the session relay.sh runs from.
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent')
        self.foreign('parent', sock='/tmp/relay-sock')       # relay.sh's own pane: $TMUX names that server
        env = dict(self.env, TMUX='/tmp/relay-sock,0,0', TEST_TMUX_SESSION='parent')
        x, log = self.run_relay(env=env, ok=False, envelopes=[self.envelope('e5', 'target: tmux:parent\n\n[player x] DONE: own session', frm='peerA')])
        self.assertIn('relay.sh: delivered to tmux:parent', x.stderr)
        self.assertEqual(self.settled(log, 'msg.ack'), ['e5'])
    def test_relay_refuses_target_outside_allowlist(self):
        # An envelope naming the user's own session (never passed to --allow) must not be pasted
        # into it, whatever pane_owned_by_agent would otherwise say about that pane; it is deferred
        # with the reason, so it stays in beam's refused list instead of stalling the queue.
        self.spawn('--agent', 'claude', '--orchestrator', 'tmux:parent')
        self.foreign('users-own-session'); self.clear_log()
        x, log = self.run_relay('--allow', 'tmux:parent', ok=False,
                                envelopes=[self.envelope('e6', 'target: tmux:users-own-session\n\npaste this into the user', frm='attacker-peer'),
                                           self.envelope('e7', 'no header here'),
                                           self.envelope('e8', 'target: tmux:bad:name\n\nx')])
        self.assertIn('outside this relay', x.stderr); self.assertIn('attacker-peer', x.stderr)
        self.assertNotIn('paste-buffer', self.tmux_log())                     # nothing was ever typed into it
        self.assertEqual(self.settled(log, 'msg.ack'), [])
        self.assertEqual(self.settled(log, 'msg.defer'), ['e6', 'e7', 'e8'])
        reasons = [r['reason'] for _, r in log if r.get('op') == 'msg.defer']
        self.assertIn('outside this relay', reasons[0]); self.assertIn("no 'target: ' header", reasons[1]); self.assertIn('invalid local target', reasons[2])
    def test_relay_exits_when_beam_refuses_the_subscription(self):
        x, _ = self.run_relay('--allow', 'codex:'+ID, ok=False, beamd_refuse_subscribe='not-enrolled')
        self.assertEqual(x.returncode, 1); self.assertIn('beam refused the subscription: not-enrolled', x.stderr)
    def test_relay_requires_allow_or_a_tmux_pane(self):
        self.stub('beam', BEAM_MOCK)
        x = self.orch('relay.sh', cwd=self.base, ok=False)
        self.assertEqual(x.returncode, 2); self.assertIn('pass --allow', x.stderr)
        self.assertEqual(self.beam_calls(), [])          # refused before it ever touched beam
    def test_adopt_remote_writes_beam_qualified_orchestrator_tag(self):
        self.env['TEST_PANE_ALIVE'] = '1'; self.spawn('--agent', 'codex'); self.stub('beam', BEAM_MOCK)
        self.env['TEST_BEAM_PEER_ID'] = PEER
        x = self.orch('adopt.sh', self.session, '--orchestrator', 'tmux:new-parent', '--machine', 'workbox')
        self.assertEqual(x.returncode, 0, x.stderr)
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'beam:%s/tmux:new-parent' % PEER)
        # an already beam-qualified --orchestrator is left exactly as given
        self.orch('adopt.sh', self.session, '--orchestrator', 'beam:deadbeefcafef00ddeadbeefcafef00d/tmux:elsewhere', '--machine', 'workbox')
        self.assertEqual(self.tag('@session-x-orchestra-orchestrator'), 'beam:deadbeefcafef00ddeadbeefcafef00d/tmux:elsewhere')
    def test_repo_root_resolves_remotely(self):
        self.stub('beam', BEAM_MOCK)
        out = self.lib('ORCH_MACHINE=workbox; ORCH_REPO="$1"; repo_root', str(self.repo))
        self.assertEqual(out.strip(), str(self.repo.resolve()))
        self.assertTrue(any(c[:2] == ['exec', 'workbox'] and 'realpath' in c for c in self.beam_calls()), self.beam_calls())

    # --- the invariant: --machine must never touch this machine ------------------------------
    # The review's headline finding: the old mock ran a "remote" beam exec on the same host, same
    # PATH, same tmux state as a local call, so a --machine spawn that created its worktree and
    # tmux session LOCALLY passed every test. enable_remote_machine (above) gives a correctly
    # routed call a genuinely different tmux server (a separate state file), PATH and HOME; a
    # script that still calls tmux/git bare keeps landing in THIS machine's state regardless.
    def test_machine_spawn_creates_nothing_on_this_machine(self):
        self.enable_remote_machine()
        self.env['TEST_PANE_ALIVE'] = '1'
        remote_repo = self.remote/'remote-repo'; self.git_init(remote_repo)
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(remote_repo), '--machine', 'workbox',
                           '--branch', 'feature/remote', '--from', 'HEAD', '--prompt', 'p', '--no-node-modules', '--agent', 'codex'])
        self.assertEqual(x.returncode, 0, x.stderr)
        self.assertFalse((self.base/'tmux-state.json').exists(), 'a local tmux server was started')
        self.assertFalse((self.repo/'.claude/worktrees').exists(), 'a worktree was created in the local repo')
        self.assertFalse((self.base/'calls').exists(), 'a harness ran locally instead of on the remote machine')
        rname = 'remote-repo-feature-remote'
        rstate = self.remote_state()
        self.assertEqual(sorted(rstate), [rname], rstate)
        self.assertEqual(rstate[rname]['options']['@session-x-orchestra-branch'], 'feature/remote')
        self.assertEqual(rstate[rname]['options']['@session-worktree'], str((remote_repo/'.claude/worktrees/feature-remote').resolve()))
        self.assertEqual(rstate[rname]['options']['@session-repo'], str(remote_repo.resolve()))
        self.assertTrue((remote_repo/'.claude/worktrees/feature-remote').is_dir())
        self.assertEqual(self.remote_calls()[-1]['cli'], 'codex')
        self.assertTrue(any(c[:2] == ['exec', 'workbox'] and 'new-session' in c for c in self.beam_calls()), self.beam_calls())
        self.rname = rname; self.remote_repo = remote_repo
    def test_machine_dir_spawn_uses_the_remote_directory(self):
        self.enable_remote_machine(); self.env['TEST_PANE_ALIVE'] = '1'
        d = self.remote/'scratch'; d.mkdir()
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--machine', 'workbox', '--dir', 'scratch', '--prompt', 'p'], ok=False)
        self.assertEqual(x.returncode, 2); self.assertIn('--dir must be an absolute path', x.stderr)
        self.run_cmd(['bash', self.script('spawn.sh'), '--machine', 'workbox', '--dir', str(d), '--prompt', 'p', '--agent', 'codex'])
        self.assertFalse((self.base/'tmux-state.json').exists(), 'a local tmux server was started')
        opts = self.remote_state()['scratch-dir']['options']
        self.assertEqual((opts['@session-x-orchestra-session-type'], opts['@session-cwd'], opts['@session-x-orchestra-orchestrator']), ('dir', str(d.resolve()), 'beam:%s/codex:%s' % ('a'*32, ID)))
        self.assertEqual(self.remote_calls()[-1]['cwd'], str(d.resolve()))
        self.assertEqual([r['session'] for r in self.sessions('--all', '--machine', 'workbox')], ['scratch-dir'])
        self.orch('kill.sh', 'scratch-dir', '--machine', 'workbox'); self.assertEqual(self.remote_state(), {})
    def test_machine_spawn_runs_the_launcher_installed_on_the_remote_machine(self):
        # The pane runs _launch.sh on the target, where this machine's absolute plugin path does
        # not exist: the launcher is the one under the target's own $HOME, at the same path
        # relative to $HOME as here (Claude Code's plugin cache), and nothing here is referenced.
        # The pane command is a POSIX sh line, since the target may have no /bin/bash (NixOS).
        self.enable_remote_machine()
        self.env['TEST_PANE_ALIVE'] = '1'
        remote_repo = self.remote/'remote-repo'; self.git_init(remote_repo)
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(remote_repo), '--machine', 'workbox',
                           '--branch', 'feature/remote', '--from', 'HEAD', '--prompt', 'p', '--no-node-modules', '--agent', 'codex'])
        self.assertEqual(x.returncode, 0, x.stderr)
        launch = next(c for c in self.beam_calls() if c[:2] == ['exec', 'workbox'] and 'respawn-pane' in c)
        # /bin/sh, not /bin/bash: NixOS has only /bin/sh at a fixed path, bash lives on PATH.
        self.assertNotIn('/bin/bash', launch, launch)
        cmd = launch[launch.index('-c', launch.index('/bin/sh')) + 1]
        self.assertIn(str(self.remote_home/'skills/orchestrator/scripts/_launch.sh'), cmd, cmd)
        self.assertNotIn(self.script('_launch.sh'), cmd, cmd)
        self.assertEqual(self.remote_calls()[-1]['cli'], 'codex')
    def test_machine_spawn_refuses_when_the_remote_machine_has_no_launcher(self):
        self.enable_remote_machine()
        (self.remote_home/'skills').unlink()                                 # installed here, not under the remote $HOME
        remote_repo = self.remote/'remote-repo'; self.git_init(remote_repo)
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(remote_repo), '--machine', 'workbox',
                           '--branch', 'feature/remote', '--from', 'HEAD', '--prompt', 'p', '--no-node-modules', '--agent', 'codex'], ok=False)
        self.assertNotEqual(x.returncode, 0)
        self.assertIn('~/skills/orchestrator/scripts/_launch.sh does not exist on workbox', x.stderr)
        self.assertIn('install the orchestra plugin there', x.stderr)
        self.assertFalse((remote_repo/'.claude/worktrees').exists(), 'a worktree was created before the launcher check')
        self.assertEqual(self.remote_state(), {}, 'a session was created before the launcher check')
    def test_machine_adopt_send_screen_kill_touch_only_the_remote_machine(self):
        self.test_machine_spawn_creates_nothing_on_this_machine()      # builds the remote session and asserts spawn's own invariant
        rname, remote_repo = self.rname, self.remote_repo
        local_snapshot = (self.base/'tmux-state.json').exists()        # still False: spawn touched nothing locally
        x = self.orch('adopt.sh', rname, '--repo', str(remote_repo), '--machine', 'workbox', '--orchestrator', 'tmux:new-parent')
        self.assertEqual(x.returncode, 0, x.stderr)
        # a remote adoption is beam-qualified with this (the orchestrator's) machine's own peerId,
        # learned locally (beam_own_peer_id never goes through the executor) — see spawn.sh's
        # identical treatment and D2's "who am I" rule.
        self.assertEqual(self.remote_state()[rname]['options']['@session-x-orchestra-orchestrator'], 'beam:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/tmux:new-parent')
        self.assertFalse((self.base/'tmux-state.json').exists())
        x = self.orch('send.sh', rname, '--repo', str(remote_repo), '--machine', 'workbox', '--raw', 'ping')
        self.assertEqual(x.returncode, 0, x.stderr)
        self.assertFalse((self.base/'tmux-state.json').exists())
        x = self.orch('screen.sh', rname, '--repo', str(remote_repo), '--machine', 'workbox')
        self.assertEqual(x.returncode, 0, x.stderr)
        self.assertFalse((self.base/'tmux-state.json').exists())
        x = self.orch('kill.sh', rname, '--repo', str(remote_repo), '--machine', 'workbox')
        self.assertEqual(x.returncode, 0, x.stderr)
        self.assertNotIn(rname, self.remote_state())
        self.assertFalse((self.base/'tmux-state.json').exists())         # the whole sequence never wrote a local tmux server
        self.assertFalse(local_snapshot)
        exec_targets = {c[1] for c in self.beam_calls() if c[:1] == ['exec']}
        self.assertEqual(exec_targets, {'workbox'})
    def test_remote_socket_is_the_targets_own_and_every_script_agrees(self):
        # The socket mismatch: spawn.sh computed an explicit remote socket while send.sh, kill.sh,
        # screen.sh, adopt.sh and sessions.sh passed none, leaving the target's tmux to resolve its
        # own default — the same server only as long as that default happens to be "/tmp/tmux-<uid>".
        # Here it is not (the target keeps its sockets under its own TMUX_TMPDIR, as a sandboxed
        # runner or a hardened /tmp does), so a socket built on this machine names a server the
        # session is not on: the spawn reports success and every command after it says "no such
        # session" about a player that is alive.
        self.enable_remote_machine()
        self.env['ORCH_TEST_REMOTE_TMUX_TMPDIR'] = str(self.remote/'tmux-tmp')
        self.env['TEST_PANE_ALIVE'] = '1'
        remote_sock = '%s/tmux-%d/default' % (self.remote/'tmux-tmp', os.getuid())
        self.assertNotEqual(remote_sock, self.sock)
        remote_repo = self.remote/'remote-repo'; self.git_init(remote_repo)
        rname = 'remote-repo-feature-remote'
        args = ['--repo', str(remote_repo), '--machine', 'workbox']
        x = self.run_cmd(['bash', self.script('spawn.sh'), *args, '--branch', 'feature/remote',
                           '--from', 'HEAD', '--prompt', 'p', '--no-node-modules', '--agent', 'codex'])
        self.assertEqual(x.returncode, 0, x.stderr)
        # created on the server the TARGET named, and the pane is told that same socket
        self.assertEqual(sorted(self.remote_state()), [rname], self.remote_state())
        self.assertEqual(self.remote_calls()[-1]['env']['ORCHESTRA_SOCKET'], remote_sock)
        # …and every other script addresses it there: a listing finds it, adoption retags it,
        # send reaches it and kill removes it, all by the name spawn.sh printed.
        rows = json.loads(self.orch('sessions.sh', *args, '--all', '--json').stdout)
        self.assertEqual([r['session'] for r in rows], [rname], rows)
        self.orch('adopt.sh', rname, *args, '--orchestrator', 'tmux:new-parent')
        self.assertEqual(self.remote_state()[rname]['options']['@session-x-orchestra-orchestrator'], 'beam:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/tmux:new-parent')
        self.orch('send.sh', rname, *args, '--raw', 'ping')
        self.orch('screen.sh', rname, *args)
        self.orch('kill.sh', rname, *args)
        self.assertNotIn(rname, self.remote_state())
        # no tmux call for that machine was ever aimed at a socket path invented here
        tmux_execs = [c for c in self.beam_calls() if c[:1] == ['exec'] and 'tmux' in c]
        self.assertTrue(tmux_execs, self.beam_calls())
        for c in tmux_execs:
            self.assertIn('-S', c, c); self.assertEqual(c[c.index('-S')+1], remote_sock, c)
        self.assertFalse((self.base/'tmux-state.json').exists())
    def test_machine_sessions_listing_reads_only_the_remote_machine(self):
        self.test_machine_spawn_creates_nothing_on_this_machine()
        rows = json.loads(self.orch('sessions.sh', '--machine', 'workbox', '--repo', str(self.remote_repo), '--all', '--json').stdout)
        self.assertEqual([r['session'] for r in rows], [self.rname], rows)
        self.assertFalse((self.base/'tmux-state.json').exists())
        self.assertTrue(any(c[:2] == ['exec', 'workbox'] and 'list-panes' in c for c in self.beam_calls()), self.beam_calls())
    def test_unreachable_machine_is_not_a_missing_worktree(self):
        # A failed exec says nothing about the target's filesystem. Collapsing it into "the
        # worktree is not there" reports "nothing to resume" about a worktree that exists, and
        # walks a fresh spawn into a create path that fails for the same reason a moment later.
        self.enable_remote_machine()
        remote_repo = self.remote/'remote-repo'; self.git_init(remote_repo)
        self.env['TEST_BEAM_EXEC_FAIL'] = 'printf yes'          # only the worktree probe
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(remote_repo), '--machine', 'workbox',
                           '--branch', 'feature/remote', '--resume'], ok=False)
        self.assertNotEqual(x.returncode, 0)
        self.assertIn('could not reach workbox', x.stderr)
        self.assertNotIn('nothing to resume', x.stderr)
        # and the same probe, answering normally, still reports a worktree that is simply absent
        del self.env['TEST_BEAM_EXEC_FAIL']
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(remote_repo), '--machine', 'workbox',
                           '--branch', 'feature/remote', '--resume'], ok=False)
        self.assertIn('nothing to resume', x.stderr)
    def test_machine_spawn_skips_local_harness_path_check(self):
        # B1 (the PATH half): a remote spawn's harness check must not be answered from this
        # machine's PATH — "gemini" is stubbed nowhere in this test, local or remote, so a local
        # spawn still refuses it up front (first assertion, unchanged behaviour) while a remote
        # one must get past that check entirely (it fails later, inside the pane, not here).
        local = self.run_cmd(['bash', self.script('spawn.sh'), '--branch', 'feature/g', '--from', 'HEAD',
                               '--prompt', 'p', '--no-node-modules', '--agent', 'gemini'], ok=False)
        self.assertIn('gemini is not on PATH', local.stderr)
        self.enable_remote_machine(); self.env['TEST_PANE_ALIVE'] = '1'
        remote_repo = self.remote/'remote-repo'; self.git_init(remote_repo)
        x = self.run_cmd(['bash', self.script('spawn.sh'), '--repo', str(remote_repo), '--machine', 'workbox',
                           '--branch', 'feature/g', '--from', 'HEAD', '--prompt', 'p', '--no-node-modules', '--agent', 'gemini'])
        self.assertEqual(x.returncode, 0, x.stderr)
        self.assertNotIn('is not on PATH', x.stderr, x.stderr)

    # --- B4, B5: "who/what am I" questions must stay local even when ORCH_MACHINE is set --------
    def test_resolve_orchestrator_self_question_ignores_machine(self):
        # B4: auto-detecting the orchestrator target from $TMUX is a question about THIS machine
        # ("what session am I in"), never the target one — using tmux_on here (which honours
        # ORCH_MACHINE) would send it over beam and could answer with the remote's own idea of
        # "current session" instead. beam_calls() is the tell: it must stay empty.
        self.stub('beam', BEAM_MOCK)
        env = dict(self.env, CLAUDECODE='1', ORCH_MACHINE='workbox', TMUX='/tmp/x,0,0')
        out = self.run_cmd(['bash', '-c', '. "$0"; resolve_orchestrator ""', str(ROOT/'player/scripts/_routing.sh')], env=env, ok=False)
        self.assertEqual(out.stdout.strip(), 'tmux:parent')
        self.assertEqual(self.beam_calls(), [])
    def test_orchestra_machine_is_a_parent_session_marker(self):
        # B5, half 1: ORCHESTRA_MACHINE must be stripped from what a player's tmux server
        # captures as its global environment, the same way CLAUDECODE/CODEX_THREAD_ID are — or it
        # reaches every future pane in that session through the tmux server, not just the one
        # spawn.sh started explicitly.
        markers = self.lib('printf "%s\\n" "${PARENT_SESSION_MARKERS[@]}"').splitlines()
        self.assertIn('ORCHESTRA_MACHINE', markers)
    def test_report_ignores_inherited_orchestra_machine(self):
        # B5, half 2: even if ORCHESTRA_MACHINE reaches report.sh's environment some other way
        # (a user's shell exported it; the strip above is defence, not the only layer), report.sh
        # must still act on this machine — never silently send its own orchestrator
        # lookup over beam, which session_record's quiet failure would turn into a bare "unset or
        # unreachable" with no sign anything went over the network.
        self.spawn('--agent', 'codex'); self.stub('beam', BEAM_MOCK)
        x = self.report('PROGRESS', 'still local', env=self.player_env(ORCHESTRA_MACHINE='workbox'))
        self.assertIn('queued for', x.stdout)
        self.assertEqual(self.beam_calls(), [])

    # --- B6, B7: the dependency-free JSON scanner ----------------------------------------------
    def test_json_string_field_rejects_non_string_value(self):
        # B6: {"status":null,"label":"pwned"} must not return "pwned" for "status" — the old
        # scanner, finding no opening quote right after the colon, skipped ahead to the next
        # quote anywhere in the document and returned that field's value instead, with rc=0.
        out = self.run_cmd(['bash', '-c', '. "$0"; json_string_field "$1" status', str(ROOT/'player/scripts/_routing.sh'),
                             '{"status":null,"label":"pwned"}'], ok=False)
        self.assertNotEqual(out.returncode, 0)
        self.assertEqual(out.stdout, '')
    def test_json_string_field_is_linear_at_the_payload_cap(self):
        # B7: json_unescape, and the identical char-by-char accumulation in json_string_field's
        # own scan, were O(n^2) — about 45s at 100 KiB against beam's 256 KiB payload cap. Bounded
        # well under that at the cap itself.
        import time
        body = 'x' * 262144
        value = 'target: tmux:p\n\n' + body
        payload = json.dumps({'payload': value})
        start = time.time()
        # Argument-list limits rule out passing 256 KiB as argv; stdin is how a real envelope of
        # this size would reach a script anyway (beam's own cap, beam/docs/05-mailbox.md).
        out = self.run_cmd(['bash', '-c', '. "$0"; json_string_field "$(cat)" payload', str(ROOT/'player/scripts/_routing.sh')], stdin=payload)
        elapsed = time.time() - start
        self.assertEqual(out.stdout, value)
        self.assertLess(elapsed, 5.0, elapsed)

    # --- the contract itself ------------------------------------------------------------
    def test_scripts_carry_no_legacy_names(self):
        scripts = list(ROOT.glob('*/scripts/*.sh')); self.assertGreaterEqual(len(scripts), 9)
        text = '\n'.join(p.read_text() for p in scripts)
        for old in ('player-orchestrator', 'player-prompt', 'player-agent', 'orchestrator-mail', '@player-', 'ORCHESTRATOR_', 'ORCHESTRA_PLAYER',
                    'PLAYER_RE', 'project_key', 'session_prefix', 'kirby-', 'KIRBY'):
            self.assertNotIn(old, text, old)
        # "kirby" survives only in comments (the spawner value, the sentence that the contract is shared).
        self.assertEqual([l for l in text.splitlines() if 'kirby' in l.split('#', 1)[0].lower()], [])
        # Internal shell variables may keep the PLAYER_ prefix; nothing environment-shaped may.
        self.assertEqual(sorted(set(re.findall(r'\bPLAYER_[A-Z_]+', text))), ['PLAYER_SCRIPTS'])
        for tag in TAGS: self.assertIn(tag, text, tag)
        self.assertEqual(sorted(set(re.findall(r'@session-[a-z0-9-]+[a-z0-9]', text)) - {'@session-x-orchestra', '@session-x-n10'}), sorted(TAGS))
        self.assertEqual(re.findall(r'@orchestra-[a-z-]+', text), [])               # the legacy tags are gone, comments included
        self.assertEqual(sorted(set(re.findall(r'\bORCHESTRA_[A-Z_]+', text))),
                         ['ORCHESTRA_BEAM', 'ORCHESTRA_CLAUDE_SKILL', 'ORCHESTRA_COMMAND', 'ORCHESTRA_EFFORT', 'ORCHESTRA_FORCE_LOCAL',
                          'ORCHESTRA_HARNESS', 'ORCHESTRA_MACHINE', 'ORCHESTRA_MODE', 'ORCHESTRA_MODEL',
                          'ORCHESTRA_PERMISSION_MODE', 'ORCHESTRA_RELAY_RETRY', 'ORCHESTRA_SESSION', 'ORCHESTRA_SOCKET'])
        self.assertNotIn('list-sessions -f', text); self.assertNotIn('ls -F', text)

if __name__ == '__main__': unittest.main(verbosity=2)
