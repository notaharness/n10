#!/usr/bin/env bash
# Kill ONE player session's tmux session (its agent). Leaves the worktree and branch alone —
# retire those separately after the PR merges and all checkout users stop (SKILL.md cleanup).
# <session> is a branch (resolved in this repo, --repo, or uniquely across repos) or an exact
# tmux session name, a dir player's only name. Only a session whose record says it is a player (a
# valid @session-* record of a worktree or dir player) is killed; a session that merely wears such
# a name, the user's own terminals and n10's shell/agent tabs are refused. A task prompt buffer the
# launcher never consumed (orchestra-prompt-<session>) is deleted with the session so nothing
# stays on the server.
#
# Usage: kill.sh <session> [--repo <path>] [--machine NAME]
#   --machine: the beam peer label or peerId the session is on; default $ORCHESTRA_MACHINE,
#   else this machine. A remote --repo must be absolute or start with ~/.
. "$(dirname "$(realpath "$0")")/_lib.sh"
[ $# -ge 1 ] || { sed -n '2,13p' "$0" >&2; exit 2; }
session="$1"; shift
while [ "${1:-}" = "--repo" ] || [ "${1:-}" = "--machine" ]; do
  case "$1" in --repo) ORCH_REPO="$2";; --machine) ORCH_MACHINE="$2";; esac; shift 2
done
[ $# -eq 0 ] || { sed -n '2,13p' "$0" >&2; exit 2; }
require_valid_repo_for_machine || exit 2
# Which server this machine's sessions are on, resolved once so every tmux call below
# addresses the one spawn.sh created the session on (machine_socket, _routing.sh); a no-op,
# and one variable assignment, without --machine.
machine_socket || exit 1
target="$(resolve_session "$session")" || exit 1
is_player_session "$target" || { echo "kill.sh: $target is not a player session (it has no valid @session-* record of a $SESSION_TYPE_WORKTREE or $SESSION_TYPE_DIR player); nothing killed" >&2; exit 1; }
session_exists "$target" || exit 1
tmux_on "" kill-session -t "=$target" || { echo "kill.sh: tmux could not kill $target" >&2; exit 1; }
tmux_on "" delete-buffer -b "$(prompt_buffer_name "$target")" 2>/dev/null || :
echo "killed $target"
