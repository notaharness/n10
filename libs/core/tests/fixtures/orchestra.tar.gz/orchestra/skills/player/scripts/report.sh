#!/usr/bin/env bash
# Send one message to the orchestrator as `[player <session>] KIND: text`, where <session> is
# this player's tmux session name (a label chosen at spawn; never parsed).
#
# Usage: report.sh PROGRESS|QUESTION|BLOCKED|DONE <text…>
#        report.sh --orchestrator          print the current reporting target
#
# The target is the @orchestra-orchestrator tag on this player's own tmux session, set by
# spawn.sh and adopt.sh; a player cannot change it. claude:<session-id>, codex:<thread-id> or
# tmux:<session> when the orchestrator is on this machine; beam:<orchestrator peerId>/<one of
# those> when it is on another one, in which case delivery goes through `beam msg send` (see
# beam/docs/05-mailbox.md). A claude: target gets the report on that session's inbox socket, found
# in Claude's registry under the config dir in @orchestra-orchestrator-config (else
# $CLAUDE_CONFIG_DIR, else ~/.claude), and is never pasted anywhere. A tmux target running Claude
# Code gets it on its inbox socket too (third field "inbox"); any other agent gets it pasted into
# its pane ("paste"). The session and the socket of the server
# holding it come from ORCHESTRA_SESSION and ORCHESTRA_SOCKET (injected by spawn.sh; the pane's own
# tmux environment points at a scratch server, so every local call here passes -S), or from TMUX
# in a pane spawn.sh did not start (a Kirby session adopted by adopt.sh). No file is read or
# written. Delivery is reported only when the transport accepted the message; then
# @orchestra-last-report is set to "<KIND> <ISO-8601 UTC> <outcome>" (a parser that reads only
# the first two whitespace-separated fields still gets KIND and the timestamp). A beam send that
# comes back "stored" is still success — the message is on disk and beam keeps delivering it —
# and is worded to say so plainly, because the reader is a coding agent that would otherwise
# conclude the report was lost. Failed delivery (a local target gone or unreachable, or beam's
# own "rejected") exits nonzero and prints the target, reason, and complete original report to
# stderr so the player can handle the failure. Nothing retries.
set -eu
# A player always acts on its own machine: ORCHESTRA_FORCE_LOCAL pins ORCH_MACHINE to this
# machine regardless of any --machine/$ORCHESTRA_MACHINE this process happens to inherit (see
# _routing.sh) — report.sh's own @orchestra-orchestrator lookup must never go over beam.
ORCHESTRA_FORCE_LOCAL=1
. "$(dirname "$(realpath "$0")")/_routing.sh"
player_session_context || { player_session=""; player_socket=""; }
session="$player_session"; sock="$player_socket"; name="${session:-$(basename "$(pwd)")}"
if [ "${1:-}" = "--orchestrator" ]; then
  [ $# -eq 1 ] || { echo 'report.sh: the reporting target is the @orchestra-orchestrator tag on this session, set by spawn.sh and adopt.sh; a player cannot rebind itself' >&2; exit 2; }
  [ -n "$session" ] || { echo 'report.sh: neither ORCHESTRA_SESSION nor TMUX names a player session; not running in a player pane' >&2; exit 2; }
  target="$(tag_get "$sock" "$session" "$TAG_ORCHESTRATOR")"; printf '%s\n' "${target:-<unset>}"; exit
fi
[ $# -ge 2 ] || { sed -n '2,27p' "$0" >&2; exit 2; }
kind="$1"; shift
case "$kind" in PROGRESS|QUESTION|BLOCKED|DONE) ;; *) echo "report.sh: KIND must be PROGRESS, QUESTION, BLOCKED or DONE" >&2; exit 2;; esac
msg="[player $name] $kind: $*"
destination=""
# Keep the full destination and report intact even when tmux is unreachable; never retries.
delivery_failed() {
  printf 'report.sh: delivery failed\nTarget: %s\nReason: %s\nReport: %s\n' \
    "${destination:-<unknown>}" "$1" "$msg" >&2
  exit 1
}
delivered() {
  tag_set "$sock" "$session" "$TAG_LAST_REPORT" "$kind $(date -u +%Y-%m-%dT%H:%M:%SZ) $1" 2>/dev/null ||
    echo "report.sh: delivered, but could not set $TAG_LAST_REPORT on $session" >&2
}
[ -n "$session" ] || delivery_failed 'neither ORCHESTRA_SESSION nor TMUX names a player session; not running in a player pane'
destination="$(tag_get "$sock" "$session" "$TAG_ORCHESTRATOR")"
# No fallback to CODEX_THREAD_ID: that is the player's own conversation, not its parent.
[ -n "$destination" ] || delivery_failed "orchestrator target is unset or unreachable ($TAG_ORCHESTRATOR on $session)"
normalize_target "$destination" >/dev/null 2>&1 || delivery_failed 'invalid orchestrator target'
target="$destination"
case "$target" in
  codex:*)
    deliver_to_local_target "$sock" "$target" "$msg" || delivery_failed "$DELIVER_REASON"
    delivered delivered; echo "queued for $target"; exit 0;;
  claude:*|tmux:*)
    deliver_to_local_target "$sock" "$target" "$msg" "$(tag_get "$sock" "$session" "$TAG_ORCH_CONFIG")" ||
      delivery_failed "$DELIVER_REASON"
    delivered "$DELIVER_ROUTE"; echo "sent to ${target#*:} ($DELIVER_ROUTE)"; exit 0;;
  beam:*)
    rest="${target#beam:}"; peer="${rest%%/*}"; local_target="${rest#*/}"
    beam_cmd || delivery_failed "$(beam_unresolved_message "$peer")"
    # The far side needs to know which local target the envelope is for; beam only carries an
    # opaque payload, so it travels as a one-line header ("target: <local>") plus a blank line
    # before the report text, the way relay.sh (and this function, symmetrically) expects it.
    payload="$(printf 'target: %s\n\n%s' "$local_target" "$msg")"
    # `msg send` has no --json; it prints `delivered to <peer>` or the stored sentence and exits
    # 0, or `rejected: <reason>` (or an error token) on stderr and exits 1 (beam/docs/07-cli.md).
    # Exit 0 is the contract: anything other than "delivered" is stored, never lost.
    out="$(printf '%s' "$payload" | "${BEAM_CMD[@]}" msg send "$peer" --topic orchestra - 2>&1)" && rc=0 || rc=$?
    if [ "$rc" = 0 ]; then
      case "$out" in
        "delivered to "*) delivered delivered; echo "sent to $peer"; exit 0;;
      esac
      delivered stored
      # beam/docs/05-mailbox.md's wording for each pendingReason, which every surface uses.
      case "$out" in
        *"has not acknowledged"*)
          echo "stored for $peer; delivery pending ($peer has not acknowledged it). beam will keep delivering it until $peer does. Do not send it again.";;
        *)
          echo "stored for $peer; delivery pending ($peer is offline). beam will deliver it when $peer connects. Do not send it again.";;
      esac
      exit 0
    fi
    reason="${out%%$nl*}"; reason="${reason#rejected: }"
    delivery_failed "beam rejected the message (exit $rc): ${reason:-no reason given}";;
esac
